package com.example.data.repository

import android.content.Context
import com.example.data.model.Faq
import com.example.data.model.Scheme
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream

object SchemeIndex {

    private var loadedSchemes: List<Scheme> = emptyList()

    val schemes: List<Scheme>
        get() = loadedSchemes

    fun initialize(context: Context) {
        if (loadedSchemes.isNotEmpty()) return // Already loaded
        try {
            val jsonString = loadJsonFromAsset(context, "schemes.json")
            if (jsonString != null) {
                loadedSchemes = parseSchemes(jsonString)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadJsonFromAsset(context: Context, fileName: String): String? {
        return try {
            val inputStream: InputStream = context.assets.open(fileName)
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            String(buffer, Charsets.UTF_8)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun parseSchemes(jsonString: String): List<Scheme> {
        val list = mutableListOf<Scheme>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val id = obj.getString("id")
                val title = obj.getString("title")
                val titleHindi = obj.getString("titleHindi")
                val category = obj.getString("category")
                val description = obj.getString("description")
                val descriptionHindi = obj.getString("descriptionHindi")

                val benefits = jsonArrayToList(obj.getJSONArray("benefits"))
                val benefitsHindi = jsonArrayToList(obj.getJSONArray("benefitsHindi"))
                val eligibilityMatches = jsonArrayToList(obj.getJSONArray("eligibilityMatches"))
                val eligibilityExclusions = jsonArrayToList(obj.getJSONArray("eligibilityExclusions"))
                val eligibilityHindiMatches = jsonArrayToList(obj.getJSONArray("eligibilityHindiMatches"))
                val eligibilityHindiExclusions = jsonArrayToList(obj.getJSONArray("eligibilityHindiExclusions"))
                val requiredDocuments = jsonArrayToList(obj.getJSONArray("requiredDocuments"))
                val requiredDocumentsHindi = jsonArrayToList(obj.getJSONArray("requiredDocumentsHindi"))
                val applyProcess = jsonArrayToList(obj.getJSONArray("applyProcess"))
                val applyProcessHindi = jsonArrayToList(obj.getJSONArray("applyProcessHindi"))

                val faqList = mutableListOf<Faq>()
                val faqArray = obj.getJSONArray("faqList")
                for (j in 0 until faqArray.length()) {
                    val faqObj = faqArray.getJSONObject(j)
                    faqList.add(
                        Faq(
                            question = faqObj.getString("question"),
                            questionHindi = faqObj.getString("questionHindi"),
                            answer = faqObj.getString("answer"),
                            answerHindi = faqObj.getString("answerHindi")
                        )
                    )
                }

                val officialWebsite = obj.optString("officialWebsite", "https://www.india.gov.in/")
                val imageUrl = obj.optString("imageUrl", "")
                val badge = obj.optString("badge", "Financial Aid")
                val fundingType = obj.optString("fundingType", "₹6,000 / Year")
                val frequency = obj.optString("frequency", "3 Installments")

                list.add(
                    Scheme(
                        id = id,
                        title = title,
                        titleHindi = titleHindi,
                        category = category,
                        description = description,
                        descriptionHindi = descriptionHindi,
                        benefits = benefits,
                        benefitsHindi = benefitsHindi,
                        eligibilityMatches = eligibilityMatches,
                        eligibilityExclusions = eligibilityExclusions,
                        eligibilityHindiMatches = eligibilityHindiMatches,
                        eligibilityHindiExclusions = eligibilityHindiExclusions,
                        requiredDocuments = requiredDocuments,
                        requiredDocumentsHindi = requiredDocumentsHindi,
                        applyProcess = applyProcess,
                        applyProcessHindi = applyProcessHindi,
                        faqList = faqList,
                        officialWebsite = officialWebsite,
                        imageUrl = imageUrl,
                        badge = badge,
                        fundingType = fundingType,
                        frequency = frequency
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun jsonArrayToList(array: JSONArray): List<String> {
        val list = mutableListOf<String>()
        for (i in 0 until array.length()) {
            list.add(array.getString(i))
        }
        return list
    }

    fun getSchemeById(id: String): Scheme? = schemes.find { it.id == id }
}
