package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// Pre-seeded or dynamic schemes
data class Scheme(
    val id: String,
    val title: String,
    val titleHindi: String,
    val category: String, // Agriculture, Health, Housing, Education, Women & Child, Employment, Business
    val description: String,
    val descriptionHindi: String,
    val benefits: List<String>,
    val benefitsHindi: List<String>,
    val eligibilityMatches: List<String>, // positive matching conditions (e.g. Farmer, Tenant)
    val eligibilityExclusions: List<String>, // negative matching conditions
    val eligibilityHindiMatches: List<String>,
    val eligibilityHindiExclusions: List<String>,
    val requiredDocuments: List<String>,
    val requiredDocumentsHindi: List<String>,
    val applyProcess: List<String>,
    val applyProcessHindi: List<String>,
    val faqList: List<Faq>,
    val officialWebsite: String = "https://www.india.gov.in/",
    val imageUrl: String = "",
    val badge: String = "Financial Aid",
    val fundingType: String = "₹6,000 / Year",
    val frequency: String = "3 Installments"
)

data class Faq(
    val question: String,
    val questionHindi: String,
    val answer: String,
    val answerHindi: String
)

@Entity(tableName = "saved_schemes")
data class SavedSchemeEntity(
    @PrimaryKey val schemeId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "applications")
data class ApplicationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val schemeId: String,
    val schemeTitle: String,
    val schemeCategory: String,
    val appliedDate: String,
    val status: String, // "Documents Pending", "Form Submitted", "Under Review", "Approved"
    val statusDetails: String,
    val isPaidAssistance: Boolean,
    val paidAmount: Int,
    val missingDocuments: String, // Comma separated, e.g. "Aadhaar Card, Land Record"
    val uploadedDocuments: String = "" // Comma separated, e.g. "aadhaar.pdf"
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String, // "user" or "ai"
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: String = "current_user",
    val name: String = "Rajesh Kumar",
    val age: Int = 120,
    val state: String = "Uttar Pradesh",
    val city: String = "Lucknow",
    val occupation: String = "Farmer", // Farmer, Student, Homemaker, Self-Employed, Retired
    val annualIncome: Int = 150000,
    val category: String = "General", // OBC, SC, ST, General
    val hasDisability: Boolean = false,
    val isKycVerified: Boolean = true,
    val languagePreference: String = "Hindi" // English or Hindi
)
