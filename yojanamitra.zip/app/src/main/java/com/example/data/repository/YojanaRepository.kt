package com.example.data.repository

import com.example.data.database.YojanaDao
import com.example.data.model.SavedSchemeEntity
import com.example.data.model.ApplicationEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.UserProfileEntity
import com.example.data.model.Scheme
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class YojanaRepository(private val yojanaDao: YojanaDao) {

    // --- Schemes Cache & Helper ---
    val allSchemes: List<Scheme> = SchemeIndex.schemes

    fun dynamicRecommendSchemes(profile: UserProfileEntity): List<Scheme> {
        return allSchemes.filter { scheme ->
            // Simple robust matching criteria
            val matchesCategory = when (profile.occupation.lowercase()) {
                "farmer" -> scheme.category == "Agriculture" || scheme.category == "Health" || scheme.category == "Housing"
                "student" -> scheme.category == "Education" || scheme.category == "Employment"
                "homemaker" -> scheme.category == "Women & Child" || scheme.category == "Health"
                else -> true
            }
            val matchesIncome = when {
                profile.annualIncome < 200000 -> true
                else -> scheme.id != "ayushman_bharat" // Ayushman Bharat has lower income limits
            }
            matchesCategory && matchesIncome
        }
    }

    // --- Saved Schemes mapping ---
    val savedSchemeIds: Flow<List<String>> = yojanaDao.getSavedSchemes().map { list ->
        list.map { it.schemeId }
    }

    fun isSchemeSaved(schemeId: String): Flow<Boolean> = yojanaDao.isSchemeSaved(schemeId)

    suspend fun toggleBookmark(schemeId: String) {
        val savedList = yojanaDao.getSavedSchemes()
        // Wait, simpler, directly check if already saved
        val isSaved = yojanaDao.getUserProfile() // dummy check, let's toggle surgically
        // To avoid flow reading delay inside suspend, we can simple insert or remove
        // based on a state. Or let's just insert directly or remove first:
        // We'll write a clean helper:
        yojanaDao.getSavedSchemes().map { list ->
            list.any { it.schemeId == schemeId }
        }.collect { exists ->
            if (exists) {
                yojanaDao.removeSavedScheme(schemeId)
            } else {
                yojanaDao.saveScheme(SavedSchemeEntity(schemeId))
            }
        }
    }

    suspend fun saveScheme(schemeId: String) {
        yojanaDao.saveScheme(SavedSchemeEntity(schemeId))
    }

    suspend fun deleteSavedScheme(schemeId: String) {
        yojanaDao.removeSavedScheme(schemeId)
    }

    // --- Applications Flow ---
    val allApplications: Flow<List<ApplicationEntity>> = yojanaDao.getAllApplications()

    suspend fun applyForScheme(
        schemeId: String,
        schemeTitle: String,
        schemeCategory: String,
        isPaidAssistance: Boolean,
        paidAmount: Int,
        missingDocs: List<String>
    ) {
        val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
        val currentDate = dateFormat.format(java.util.Date())
        val application = ApplicationEntity(
            schemeId = schemeId,
            schemeTitle = schemeTitle,
            schemeCategory = schemeCategory,
            appliedDate = currentDate,
            status = "Documents Pending",
            statusDetails = if (isPaidAssistance) 
                "An executive has been assigned. Please submit Aadhaar-linked OTP and missing records." 
            else 
                "Application started. Please complete self-verification steps.",
            isPaidAssistance = isPaidAssistance,
            paidAmount = paidAmount,
            missingDocuments = missingDocs.joinToString(", ")
        )
        yojanaDao.insertApplication(application)
    }

    suspend fun updateApplication(application: ApplicationEntity) {
        yojanaDao.updateApplication(application)
    }

    suspend fun deleteApplication(id: Int) {
        yojanaDao.deleteApplication(id)
    }


    // --- Chat Flow ---
    val chatHistory: Flow<List<ChatMessageEntity>> = yojanaDao.getChatMessages()

    suspend fun addChatMessage(sender: String, message: String) {
        yojanaDao.insertChatMessage(ChatMessageEntity(sender = sender, message = message))
    }

    suspend fun clearChat() {
        yojanaDao.clearChatHistory()
    }


    // --- Profile Flow ---
    val userProfile: Flow<UserProfileEntity> = yojanaDao.getUserProfileFlow().map { profile ->
        profile ?: UserProfileEntity() // Default pre-made profile for Rajesh Kumar
    }

    suspend fun saveProfile(profile: UserProfileEntity) {
        yojanaDao.saveUserProfile(profile)
    }

    suspend fun updateLanguage(lang: String) {
        val current = yojanaDao.getUserProfile() ?: UserProfileEntity()
        yojanaDao.saveUserProfile(current.copy(languagePreference = lang))
    }
}
