package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.SavedSchemeEntity
import com.example.data.model.ApplicationEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.UserProfileEntity

@Database(
    entities = [
        SavedSchemeEntity::class,
        ApplicationEntity::class,
        ChatMessageEntity::class,
        UserProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class YojanaDatabase : RoomDatabase() {
    abstract fun yojanaDao(): YojanaDao

    companion object {
        @Volatile
        private var INSTANCE: YojanaDatabase? = null

        fun getDatabase(context: Context): YojanaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    YojanaDatabase::class.java,
                    "yojana_mitra_db"
                )
                .fallbackToDestructiveMigration(true)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
