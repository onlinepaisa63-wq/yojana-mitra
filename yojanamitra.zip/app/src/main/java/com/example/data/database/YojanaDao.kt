package com.example.data.database

import androidx.room.*
import com.example.data.model.SavedSchemeEntity
import com.example.data.model.ApplicationEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface YojanaDao {

    // --- Saved Schemes ---
    @Query("SELECT * FROM saved_schemes")
    fun getSavedSchemes(): Flow<List<SavedSchemeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveScheme(entity: SavedSchemeEntity)

    @Query("DELETE FROM saved_schemes WHERE schemeId = :schemeId")
    suspend fun removeSavedScheme(schemeId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_schemes WHERE schemeId = :schemeId)")
    fun isSchemeSaved(schemeId: String): Flow<Boolean>


    // --- Applications ---
    @Query("SELECT * FROM applications ORDER BY id DESC")
    fun getAllApplications(): Flow<List<ApplicationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApplication(entity: ApplicationEntity)

    @Update
    suspend fun updateApplication(entity: ApplicationEntity)

    @Query("SELECT * FROM applications WHERE id = :id")
    suspend fun getApplicationById(id: Int): ApplicationEntity?

    @Query("DELETE FROM applications WHERE id = :id")
    suspend fun deleteApplication(id: Int)


    // --- Chat History ---
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getChatMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearChatHistory()


    // --- User Profile ---
    @Query("SELECT * FROM user_profile WHERE id = 'current_user'")
    fun getUserProfileFlow(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 'current_user'")
    suspend fun getUserProfile(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfileEntity)
}
