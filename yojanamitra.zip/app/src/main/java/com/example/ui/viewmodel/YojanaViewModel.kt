package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.database.YojanaDatabase
import com.example.data.model.ApplicationEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.UserProfileEntity
import com.example.data.model.Scheme
import com.example.data.repository.SchemeIndex
import com.example.data.repository.YojanaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed interface ChatUiState {
    object Idle : ChatUiState
    object Loading : ChatUiState
    data class Success(val response: String) : ChatUiState
    data class Error(val error: String) : ChatUiState
}

data class SupportTicket(
    val id: String,
    val subject: String,
    val description: String,
    val status: String, // "Open", "In Progress", "Resolved"
    val createdAt: String
)

data class NotificationItem(
    val id: String,
    val type: String, // "Email", "SMS"
    val recipient: String,
    val message: String,
    val timestamp: String
)

data class PaymentTransaction(
    val id: String,
    val orderId: String,
    val schemeName: String,
    val amount: Int,
    val method: String,
    val status: String, // "Successful", "Refunded"
    val timestamp: String
)

class YojanaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = YojanaDatabase.getDatabase(application)
    private val repository = YojanaRepository(database.yojanaDao())

    // --- Core UI Navigation State ---
    private val _currentScreen = MutableStateFlow("home") // home, schemes_list, scheme_detail, ai_finder, dashboard, profile, chat_assistant, payment
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // --- Selected Scheme for details view ---
    private val _selectedSchemeId = MutableStateFlow<String?>(null)
    val selectedSchemeId: StateFlow<String?> = _selectedSchemeId.asStateFlow()

    // --- Search & Filters ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All") // All, Agriculture, Health, Housing, Education, Women & Child, Employment, Business
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // --- AI Finder Questionnaire ---
    private val _finderStep = MutableStateFlow(1) // 1 to 4
    val finderStep: StateFlow<Int> = _finderStep.asStateFlow()

    private val _answers = MutableStateFlow(QuestionnaireAnswers())
    val answers: StateFlow<QuestionnaireAnswers> = _answers.asStateFlow()

    private val _matchedSchemes = MutableStateFlow<List<Scheme>>(emptyList())
    val matchedSchemes: StateFlow<List<Scheme>> = _matchedSchemes.asStateFlow()

    // --- Saved Schemes & Applications List ---
    val savedSchemeIds: StateFlow<List<String>> = repository.savedSchemeIds
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allApplications: StateFlow<List<ApplicationEntity>> = repository.allApplications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfileEntity> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfileEntity())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.chatHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _chatUiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val chatUiState: StateFlow<ChatUiState> = _chatUiState.asStateFlow()

    // --- Payment Temp State ---
    private val _tempPaymentSchemeId = MutableStateFlow<String?>(null)
    val tempPaymentSchemeId: StateFlow<String?> = _tempPaymentSchemeId.asStateFlow()

    private val _tempPaymentServiceType = MutableStateFlow("basic") // basic (₹99), premium (₹499)
    val tempPaymentServiceType: StateFlow<String> = _tempPaymentServiceType.asStateFlow()

    // --- Scheme Application System States ---
    private val _applyFlowStep = MutableStateFlow(1) // 1 to 6
    val applyFlowStep: StateFlow<Int> = _applyFlowStep.asStateFlow()

    val formFullName = MutableStateFlow("")
    val formMobile = MutableStateFlow("")
    val formMobileOtp = MutableStateFlow("")
    val formMobileVerified = MutableStateFlow(false)
    val formEmail = MutableStateFlow("")
    val formState = MutableStateFlow("")
    val formDistrict = MutableStateFlow("")
    val formPincode = MutableStateFlow("")
    val formGender = MutableStateFlow("Male")
    val formDob = MutableStateFlow("")
    val formCategory = MutableStateFlow("General")
    val formOccupation = MutableStateFlow("")

    val formIncome = MutableStateFlow("")
    val formAnnualIncome = MutableStateFlow("")
    val formFamilyDetails = MutableStateFlow("")
    val formCaste = MutableStateFlow("")
    val formDisability = MutableStateFlow(false)
    val formFarmer = MutableStateFlow(false)
    val formStudent = MutableStateFlow(false)
    val formBusinessOwner = MutableStateFlow(false)
    val formExistingBenefits = MutableStateFlow("")

    // Uploaded docs map: DocName -> Triple(ProgressPercent, IsCompleted, FileSize)
    val uploadedDocumentsMap = MutableStateFlow<Map<String, Triple<Int, Boolean, String>>>(emptyMap())

    val isFormConfirmChecked = MutableStateFlow(false)
    val selectedPaymentMethod = MutableStateFlow("UPI")

    val generatedOrderId = MutableStateFlow("")
    val generatedAppId = MutableStateFlow("")
    val generatedPaymentId = MutableStateFlow("")
    val submissionDate = MutableStateFlow("")

    val guidanceFees = MutableStateFlow<Map<String, Int>>(mapOf(
        "pm_kisan" to 99,
        "ayushman_bharat" to 149,
        "pm_awas" to 299,
        "pm_ujjwala" to 99,
        "ladli_laxmi" to 199,
        "stand_up_india" to 299,
        "pm_kaushal" to 149
    ))

    // Tracking States
    val trackMobile = MutableStateFlow("")
    val trackAppId = MutableStateFlow("")
    val trackOtp = MutableStateFlow("")
    val trackOtpSent = MutableStateFlow(false)
    val trackOtpVerified = MutableStateFlow(false)
    val trackedApplication = MutableStateFlow<ApplicationEntity?>(null)

    // Tickets, Notifications and Payments Invoices
    val supportTickets = MutableStateFlow<List<SupportTicket>>(listOf(
        SupportTicket("TKT-1029", "Aadhaar Card mismatch error", "My Aadhaar registration name doesn't match my school cert.", "In Progress", "02 Jul 2026"),
        SupportTicket("TKT-0941", "Payment receipt not downloaded", "My payment of ₹149 was successful but couldn't get pdf.", "Resolved", "28 Jun 2026")
    ))

    val notifications = MutableStateFlow<List<NotificationItem>>(listOf(
        NotificationItem("NTF-4382", "SMS", "9876543210", "Your application for PM Kisan has been received. Track status using ID: PMK-98321.", "17 Jun 2026 10:30 AM"),
        NotificationItem("NTF-4383", "Email", "rajesh.kumar@gmail.com", "Subject: Assisted Application Fee Received. Thank you for using YojanaMitra. Invoice #INV-9283.", "17 Jun 2026 10:32 AM")
    ))

    val paymentsList = MutableStateFlow<List<PaymentTransaction>>(listOf(
        PaymentTransaction("TXN-9831", "ORD-12849", "PM Kisan Samman Nidhi", 299, "UPI", "Successful", "12 Oct 2023")
    ))

    init {
        // Initialize schemes dynamically from local JSON asset file
        SchemeIndex.initialize(application)
        // Seed default profile & applications for Rajesh Kumar if empty on startup
        seedInitialData()
    }

    private fun seedInitialData() {
        viewModelScope.launch {
            val dbDao = database.yojanaDao()
            // 1. Seed User Profile
            val existingProfile = dbDao.getUserProfile()
            if (existingProfile == null) {
                dbDao.saveUserProfile(
                    UserProfileEntity(
                        name = "Rajesh Kumar",
                        age = 32,
                        state = "Uttar Pradesh",
                        city = "Lucknow",
                        occupation = "Farmer",
                        annualIncome = 150000,
                        category = "OBC",
                        hasDisability = false,
                        isKycVerified = true,
                        languagePreference = "Hindi"
                    )
                )
            }

            // 2. Seed default Applications matching mockup
            dbDao.getAllApplications().first().let { currentApps ->
                if (currentApps.isEmpty()) {
                    dbDao.insertApplication(
                        ApplicationEntity(
                            schemeId = "pm_kisan",
                            schemeTitle = "PM Kisan Samman Nidhi",
                            schemeCategory = "Agriculture",
                            appliedDate = "12 Oct 2023",
                            status = "Documents Pending",
                            statusDetails = "Your Land Records are being verified by the local Tehsildar office. Estimated completion: 5 working days.",
                            isPaidAssistance = true,
                            paidAmount = 299,
                            missingDocuments = "Land Ownership Documents"
                        )
                    )
                    dbDao.insertApplication(
                        ApplicationEntity(
                            schemeId = "pm_ujjwala",
                            schemeTitle = "Pradhan Mantri Ujjwala Yojana",
                            schemeCategory = "Women & Child",
                            appliedDate = "05 Nov 2023",
                            status = "Documents Pending",
                            statusDetails = "Missing: Aadhar Linked Phone OTP. Please verify or request executive call.",
                            isPaidAssistance = false,
                            paidAmount = 0,
                            missingDocuments = "Aadhar Linked Phone OTP"
                        )
                    )
                }
            }
        }
    }

    // --- Safe Screen Navigation ---
    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun viewSchemeDetails(schemeId: String) {
        _selectedSchemeId.value = schemeId
        _currentScreen.value = "scheme_detail"
    }

    // --- Search & Filters Update ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    val filteredSchemes: StateFlow<List<Scheme>> = combine(
        _searchQuery,
        _selectedCategory
    ) { query, category ->
        SchemeIndex.schemes.filter { scheme ->
            val matchesQuery = scheme.title.lowercase().contains(query.lowercase()) ||
                    scheme.titleHindi.contains(query) ||
                    scheme.category.lowercase().contains(query.lowercase()) ||
                    scheme.description.lowercase().contains(query.lowercase()) ||
                    scheme.descriptionHindi.contains(query)

            val matchesCategory = category == "All" || scheme.category.equals(category, ignoreCase = true)

            matchesQuery && matchesCategory
        }
    }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SchemeIndex.schemes)

    // --- Saved Schemes Actions ---
    fun toggleSavedScheme(schemeId: String) {
        viewModelScope.launch {
            val isCurrentSaved = savedSchemeIds.value.contains(schemeId)
            if (isCurrentSaved) {
                repository.deleteSavedScheme(schemeId)
            } else {
                repository.saveScheme(schemeId)
            }
        }
    }

    // --- AI Finder Steps & Submit ---
    fun updateAnswers(updater: (QuestionnaireAnswers) -> QuestionnaireAnswers) {
        _answers.value = updater(_answers.value)
    }

    fun nextFinderStep() {
        if (_finderStep.value < 4) {
            _finderStep.value += 1
        } else {
            // Process Recommendations
            calculateFinderResults()
            _currentScreen.value = "schemes_list" // Redirect match results
            _searchQuery.value = ""
            // Set Category to "All" or a dynamic match
            _selectedCategory.value = "All"
        }
    }

    fun prevFinderStep() {
        if (_finderStep.value > 1) {
            _finderStep.value -= 1
        }
    }

    fun resetFinder() {
        _finderStep.value = 1
        _answers.value = QuestionnaireAnswers()
        _matchedSchemes.value = emptyList()
    }

    private fun calculateFinderResults() {
        val ans = _answers.value
        val profile = userProfile.value
        val matched = SchemeIndex.schemes.filter { scheme ->
            // Match Age
            val ageOk = ans.age.toIntOrNull()?.let { userAge ->
                when (scheme.id) {
                    "ladli_laxmi" -> userAge in 1..21 && ans.gender.equals("Female", ignoreCase = true)
                    else -> true
                }
            } ?: true

            // Match Occ/Category
            val matchesOcc = when (ans.occupation.lowercase()) {
                "farmer" -> scheme.category == "Agriculture" || scheme.category == "Health" || scheme.category == "Housing"
                "student" -> scheme.category == "Education" || scheme.category == "Employment"
                "women" -> scheme.category == "Women & Child" || scheme.category == "Health"
                else -> true
            }

            // Match Income
            val incomeMatches = when (ans.annualIncome) {
                "l1" -> true // less than 1 lakh gets everything
                "l2" -> scheme.id != "ayushman_bharat" // 1 - 2.5 L
                "l3" -> scheme.id != "ayushman_bharat" && scheme.id != "pm_kisan" // 2.5 - 5 L
                else -> scheme.id == "pm_kaushal" // Skill India is universal
            }

            ageOk && matchesOcc && incomeMatches
        }
        _matchedSchemes.value = matched
    }

    // --- Application Submission & Actions ---
    fun initiatePaidAssistance(schemeId: String, serviceType: String) {
        _tempPaymentSchemeId.value = schemeId
        _tempPaymentServiceType.value = serviceType
        _currentScreen.value = "payment"
    }

    fun completePaymentAndSubmit(missingDocsList: List<String>) {
        val schemeId = _tempPaymentSchemeId.value ?: return
        val isPremium = _tempPaymentServiceType.value == "premium"
        val price = if (isPremium) 499 else 199
        val scheme = SchemeIndex.getSchemeById(schemeId) ?: return

        viewModelScope.launch {
            repository.applyForScheme(
                schemeId = schemeId,
                schemeTitle = scheme.title,
                schemeCategory = scheme.category,
                isPaidAssistance = true,
                paidAmount = price,
                missingDocs = missingDocsList
            )
            // Redirect to User Dashboard
            _currentScreen.value = "dashboard"
            // Reset state
            _tempPaymentSchemeId.value = null
        }
    }

    fun applyFreeSelf(schemeId: String, missingDocsList: List<String>) {
        val scheme = SchemeIndex.getSchemeById(schemeId) ?: return
        viewModelScope.launch {
            repository.applyForScheme(
                schemeId = schemeId,
                schemeTitle = scheme.title,
                schemeCategory = scheme.category,
                isPaidAssistance = false,
                paidAmount = 0,
                missingDocs = missingDocsList
            )
            // Redirect to User Dashboard
            _currentScreen.value = "dashboard"
        }
    }

    fun deleteApplicationById(id: Int) {
        viewModelScope.launch {
            repository.deleteApplication(id)
        }
    }

    fun updateApplication(application: ApplicationEntity) {
        viewModelScope.launch {
            repository.updateApplication(application)
        }
    }

    // --- Scheme Application System Actions ---
    fun startAssistedApplyFlow(schemeId: String) {
        val profile = userProfile.value
        _tempPaymentSchemeId.value = schemeId
        _applyFlowStep.value = 1
        
        // Reset and pre-fill form
        formFullName.value = profile.name
        formMobile.value = ""
        formMobileOtp.value = ""
        formMobileVerified.value = false
        formEmail.value = if (profile.name.lowercase().contains("rajesh")) "rajesh.kumar@gmail.com" else ""
        formState.value = profile.state
        formDistrict.value = profile.city
        formPincode.value = "226001"
        formGender.value = "Male"
        formDob.value = "15/08/1994"
        formCategory.value = profile.category
        formOccupation.value = profile.occupation

        formIncome.value = "₹1,50,000 / Year"
        formAnnualIncome.value = "150000"
        formFamilyDetails.value = "4 Members (Spouse, 2 Children)"
        formCaste.value = "OBC - Maurya"
        formDisability.value = profile.hasDisability
        formFarmer.value = profile.occupation.equals("Farmer", ignoreCase = true)
        formStudent.value = profile.occupation.equals("Student", ignoreCase = true)
        formBusinessOwner.value = false
        formExistingBenefits.value = "None"

        uploadedDocumentsMap.value = emptyMap()
        isFormConfirmChecked.value = false
        selectedPaymentMethod.value = "UPI"

        _currentScreen.value = "assisted_apply_flow"
    }

    fun verifyFormOtp(phone: String, otp: String) {
        if (otp == "1234" || otp.length == 4) {
            formMobileVerified.value = true
        }
    }

    fun simulateDocumentUpload(docType: String) {
        viewModelScope.launch {
            val sizes = listOf("1.2 MB", "2.5 MB", "4.1 MB", "820 KB", "3.1 MB", "5.4 MB")
            val size = sizes.random()
            uploadedDocumentsMap.value = uploadedDocumentsMap.value + (docType to Triple(0, false, size))
            
            // Simulating progress
            for (progress in 10..100 step 20) {
                kotlinx.coroutines.delay(100)
                uploadedDocumentsMap.value = uploadedDocumentsMap.value + (docType to Triple(progress, progress == 100, size))
            }
        }
    }

    fun submitAssistedApplication() {
        val schemeId = _tempPaymentSchemeId.value ?: "pm_kisan"
        val scheme = SchemeIndex.getSchemeById(schemeId) ?: return
        val fee = guidanceFees.value[schemeId] ?: 199
        val appNum = (100000..999999).random()
        val orderNum = (10000000..99999999).random()
        val payNum = (100000..999999).random()

        generatedAppId.value = "APP-$appNum"
        generatedOrderId.value = "ORD-$orderNum"
        generatedPaymentId.value = "PAY-YJN$payNum"
        
        val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
        val currentDate = dateFormat.format(java.util.Date())
        submissionDate.value = currentDate

        viewModelScope.launch {
            val app = ApplicationEntity(
                schemeId = schemeId,
                schemeTitle = scheme.title,
                schemeCategory = scheme.category,
                appliedDate = currentDate,
                status = "Documents Received",
                statusDetails = "Your application fee of ₹$fee has been received. Our assigned expert is verifying your uploaded documents.",
                isPaidAssistance = true,
                paidAmount = fee,
                missingDocuments = "None",
                uploadedDocuments = uploadedDocumentsMap.value.keys.joinToString(", ")
            )
            repository.updateApplication(app) // Auto saves in DB via custom DAO / insert

            // Also create a fresh application directly so it appears in flow
            // wait, applyForScheme generates basic pending docs, let's insert app surgically:
            database.yojanaDao().insertApplication(app)

            // Add payment transaction
            val newTxn = PaymentTransaction(
                id = "TXN-${(1000..9999).random()}",
                orderId = generatedOrderId.value,
                schemeName = scheme.title,
                amount = fee,
                method = selectedPaymentMethod.value,
                status = "Successful",
                timestamp = currentDate
            )
            paymentsList.value = listOf(newTxn) + paymentsList.value

            // Send simulated notification triggers
            sendSimulatedNotification(
                type = "SMS",
                recipient = formMobile.value.ifEmpty { "9876543210" },
                message = "Your Assisted Application for ${scheme.title} has been submitted. App ID: ${generatedAppId.value}. Track online."
            )
            sendSimulatedNotification(
                type = "Email",
                recipient = formEmail.value.ifEmpty { "rajesh.kumar@gmail.com" },
                message = "Assisted Application Confirmation: Your guidance fee of ₹$fee was successfully received. Assigned expert is reviewing your documents. Invoice #${generatedOrderId.value}."
            )

            // Move to Step 6 (Submitted screen)
            _applyFlowStep.value = 6
        }
    }

    fun setApplyFlowStep(step: Int) {
        if (step in 1..6) {
            _applyFlowStep.value = step
        }
    }

    fun sendSimulatedNotification(type: String, recipient: String, message: String) {
        val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy hh:mm a", java.util.Locale.getDefault())
        val currentDate = dateFormat.format(java.util.Date())
        val newNtf = NotificationItem(
            id = "NTF-${(1000..9999).random()}",
            type = type,
            recipient = recipient,
            message = message,
            timestamp = currentDate
        )
        notifications.value = listOf(newNtf) + notifications.value
    }

    fun submitSupportTicket(subject: String, description: String) {
        val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
        val currentDate = dateFormat.format(java.util.Date())
        val newTicket = SupportTicket(
            id = "TKT-${(1000..9999).random()}",
            subject = subject,
            description = description,
            status = "Open",
            createdAt = currentDate
        )
        supportTickets.value = listOf(newTicket) + supportTickets.value
    }

    // Tracking helpers
    fun sendTrackingOtp(phone: String, appId: String) {
        trackOtpSent.value = true
        trackOtpVerified.value = false
        trackedApplication.value = null
    }

    fun verifyTrackingOtpAndSearch(phone: String, appId: String, otp: String) {
        if (otp == "1234" || otp.length == 4) {
            trackOtpVerified.value = true
            // Search in DB
            viewModelScope.launch {
                val match = allApplications.value.find { 
                    it.schemeId.equals(appId, ignoreCase = true) || 
                    it.schemeTitle.contains(appId, ignoreCase = true) ||
                    "APP-${it.id}".equals(appId, ignoreCase = true) ||
                    appId.contains(it.id.toString())
                }
                if (match != null) {
                    trackedApplication.value = match
                } else {
                    // Show a simulated nice application matching the query
                    trackedApplication.value = ApplicationEntity(
                        id = 9021,
                        schemeId = "pm_kisan",
                        schemeTitle = "PM Kisan Samman Nidhi",
                        schemeCategory = "Agriculture",
                        appliedDate = "04 Jul 2026",
                        status = "Under Review",
                        statusDetails = "Expert Verified. Documents are submitted to Sub-Divisional Magistrate office.",
                        isPaidAssistance = true,
                        paidAmount = 149,
                        missingDocuments = "None"
                    )
                }
            }
        }
    }

    // Admin panel functions
    fun adminUpdateStatus(appId: Int, newStatus: String, details: String) {
        viewModelScope.launch {
            val dbDao = database.yojanaDao()
            val existing = dbDao.getApplicationById(appId)
            if (existing != null) {
                val updated = existing.copy(status = newStatus, statusDetails = details)
                dbDao.updateApplication(updated)
                
                // Trigger notification alert
                sendSimulatedNotification(
                    type = "SMS",
                    recipient = "9876543210",
                    message = "Your Yojana Application #${existing.id} status updated to: $newStatus. Status details: $details"
                )
            }
        }
    }

    fun adminAssignExpert(appId: Int, expertName: String) {
        viewModelScope.launch {
            val dbDao = database.yojanaDao()
            val existing = dbDao.getApplicationById(appId)
            if (existing != null) {
                val details = "Expert Executive $expertName has been assigned to verify and file your application. Contact details sent via SMS."
                val updated = existing.copy(status = "Expert Assigned", statusDetails = details)
                dbDao.updateApplication(updated)

                sendSimulatedNotification(
                    type = "SMS",
                    recipient = "9876543210",
                    message = "Expert Assigned! Senior Officer $expertName has been assigned to your Yojana application ID #${existing.id}."
                )
            }
        }
    }

    fun adminConfigureFee(schemeId: String, newFee: Int) {
        val current = guidanceFees.value.toMutableMap()
        current[schemeId] = newFee
        guidanceFees.value = current
    }

    fun adminRefundPayment(appId: Int) {
        viewModelScope.launch {
            val dbDao = database.yojanaDao()
            val existing = dbDao.getApplicationById(appId)
            if (existing != null) {
                val updated = existing.copy(
                    status = "Completed",
                    statusDetails = "Application cancelled and assisted application fee of ₹${existing.paidAmount} has been refunded fully.",
                    paidAmount = 0
                )
                dbDao.updateApplication(updated)

                // Update transactions list
                paymentsList.value = paymentsList.value.map { txn ->
                    if (txn.schemeName.equals(existing.schemeTitle, ignoreCase = true)) {
                        txn.copy(status = "Refunded")
                    } else {
                        txn
                    }
                }

                sendSimulatedNotification(
                    type = "SMS",
                    recipient = "9876543210",
                    message = "Refund Issued: Your service assistance payment of ₹${existing.paidAmount} has been refunded. Bank turnaround: 2-3 working days."
                )
            }
        }
    }

    // --- Profile & Theme Updates ---
    fun updateProfile(profile: UserProfileEntity) {
        viewModelScope.launch {
            repository.saveProfile(profile)
        }
    }

    fun toggleLanguage() {
        viewModelScope.launch {
            val currentLang = userProfile.value.languagePreference
            val nextLang = if (currentLang == "Hindi") "English" else "Hindi"
            repository.updateLanguage(nextLang)
        }
    }

    // --- AI Chat Assistant using Direct Gemini REST API ---
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun postChatMessage(userText: String) {
        if (userText.trim().isEmpty()) return

        viewModelScope.launch {
            // 1. Post User message instantly to UI
            repository.addChatMessage("user", userText)
            _chatUiState.value = ChatUiState.Loading

            // 2. Call Gemini
            val botResponse = callGeminiApi(userText)

            // 3. Save reply
            repository.addChatMessage("ai", botResponse)
            _chatUiState.value = ChatUiState.Idle
        }
    }

    private suspend fun callGeminiApi(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w("GeminiApi", "Warning: Gemini API Key is empty or placeholder! Using fallback mock matches.")
            // Real mock advice for Indian citizen
            return@withContext getMockResponseForUserText(prompt)
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        val systemInstruction = "You are YojanaMitra (योजनामित्र), an elite, highly empathetic AI citizen counselor for Indian Government Schemes. Welcome the user contextually in Hindi or English (based on input language). Analyze query (farmers, students, women, business) and directly suggest eligible schemes out of the catalog (PM Kisan, Ayushman Bharat, PMAY, Ladli Laxmi, PMKVY, PM Ujjwala). Give the requirements and steps in bullet points clearly."

        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            })
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", systemInstruction)
                    })
                })
            })
        }

        val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string()
                if (response.isSuccessful && bodyString != null) {
                    val jsonObj = JSONObject(bodyString)
                    val candidates = jsonObj.optJSONArray("candidates")
                    val firstCandidate = candidates?.optJSONObject(0)
                    val content = firstCandidate?.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text")
                    text ?: "क्षमा करें, मुझे इस समय प्रतिक्रिया देने में कठिनाई हो रही है।"
                } else {
                    Log.e("GeminiApi", "API error: ${response.code} ${response.message}")
                    getMockResponseForUserText(prompt)
                }
            }
        } catch (e: IOException) {
            Log.e("GeminiApi", "Network exception", e)
            getMockResponseForUserText(prompt)
        } catch (e: Exception) {
            Log.e("GeminiApi", "JSON parsing exception", e)
            getMockResponseForUserText(prompt)
        }
    }

    private fun getMockResponseForUserText(prompt: String): String {
        val lowercase = prompt.lowercase()
        return when {
            lowercase.contains("किसान") || lowercase.contains("kisan") || lowercase.contains("farm") -> {
                """
                **नमस्ते! योजनामित्र में आपका स्वागत है।**

                किसानों के लिए प्रमुख योजनाएं निम्नलिखित हैं:

                1. **पीएम किसान सम्मान निधि (PM-Kisan)**
                   - **लाभ:** ₹6,000 प्रति वर्ष (₹2000 की 3 किस्तें)।
                   - **पात्रता:** सभी छोटे और सीमांत भूमिधारक किसान परिवार।
                   - **आवश्यक दस्तावेज:** आधार कार्ड, बैंक पासबुक, खसरा/खतौनी की प्रति।

                2. **प्रधानमंत्री आवास योजना (PMAY)**
                   - **लाभ:** पक्के घर के निर्माण हेतु ₹1.2 लाख तक की सहायता।

                *आप 'Apply Now' पर क्लिक करके विस्तृत विवरण देख सकते हैं या आवेदन सहायता के लिए 'Get Expert Help' चुन सकते हैं।*
                """.trimIndent()
            }
            lowercase.contains("छात्र") || lowercase.contains("scholarship") || lowercase.contains("student") -> {
                """
                **नमस्ते! योजनामित्र में आपका स्वागत है।**

                छात्रों / युवाओं के लिए महत्वपूर्ण योजनाएं:

                1. **पीएम कौशल विकास योजना (PMKVY)**
                   - **लाभ:** पूर्णतः निःशुल्क व्यावसायिक प्रशिक्षण, मान्यता प्राप्त प्रमाण पत्र, और प्लेसमेंट सहायता।
                   - **पात्रता:** बेरोजगार युवा या स्कूल/कॉलेज ड्रॉपआउट।
                   - **आवश्यक दस्तावेज:** आधार कार्ड, शैक्षणिक प्रमाण पत्र, बैंक पासबुक।

                2. **लाड़ली लक्ष्मी योजना (Ladli Laxmi)**
                   - **बालिकाओं के लिए:** निरंतर छात्रवृत्ति और 21 वर्ष में ₹1,000,000 की राशि।
                """.trimIndent()
            }
            lowercase.contains("महिला") || lowercase.contains("women") -> {
                """
                **नमस्ते! योजनामित्र में आपका स्वागत है।**

                महिलाओं के कल्याण के लिए प्रमुख सरकारी योजनाएं:

                1. **प्रधानमंत्री उज्ज्वला योजना (PMUY)**
                   - **लाभ:** मुफ्त एलपीजी गैस कनेक्शन (प्रेशर रेगुलेटर, सिलेंडर और चूल्हा जमा-मुक्त)।
                   - **पात्रता:** बीपीएल परिवार की वयस्क महिला।
                   - **आवश्यक दस्तावेज:** बीपीएल राशन कार्ड, आधार कार्ड, बैंक पासबुक।

                2. **लाड़ली लक्ष्मी योजना**
                   - **लाभ:** शिक्षा के लिए छात्रवृत्ति और बालिकाओं को भविष्य की वित्तीय सहायता।
                """.trimIndent()
            }
            lowercase.contains("स्वास्थ्य") || lowercase.contains("health") || lowercase.contains("बीमार") -> {
                """
                **नमस्ते! योजनामित्र में आपका स्वागत है।**

                स्वास्थ्य क्षेत्र की सबसे बड़ी योजना:

                1. **आयुष्मान भारत योजना (PM-JAY)**
                   - **लाभ:** प्रति परिवार प्रति वर्ष ₹5 लाख तक का कैशलेस इलाज।
                   - **पात्रता:** बीपीएल परिवार तथा एसईसीसी डेटाबेस में शामिल।
                   - **दस्तावेज:** आधार कार्ड, राशन कार्ड।
                """.trimIndent()
            }
            else -> {
                """
                **नमस्ते! मैं आपका योजनामित्र (Government Schemes AI Assistant) हूँ।**

                मैं आपको इन क्षेत्रों में पात्रता जांचने और आवेदन करने में मदद कर सकता हूँ:
                - 🌾 **कृषि और किसान कल्याण** (जैसे PM Kisan)
                - 🏥 **स्वास्थ्य सुरक्षा** (जैसे Ayushman Bharat)
                - 🏠 **आवास निर्माण** (जैसे PM Awas Yojana)
                - 👩‍🦰 **महिला एवं बाल सशक्तिकरण** (जैसे उज्ज्वला, लाड़ली लक्ष्मी)
                - 🎓 **कौशल विकास एवं रोजगार** (जैसे PMKVY)

                कृपया अपनी उम्र, राज्य या व्यवसाय बताएं ताकि मैं आपको सही सलाह दे सकूं!
                """.trimIndent()
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }
}

data class QuestionnaireAnswers(
    val age: String = "",
    val state: String = "Uttar Pradesh",
    val annualIncome: String = "l1", // l1: < 1L, l2: 1-2.5L, l3: 2.5-5L, l4: > 5L
    val occupation: String = "Farmer", // Farmer, Student, Women, Retired, MSME Business
    val gender: String = "Male", // Male, Female, Other
    val isDisabled: Boolean = false
)
