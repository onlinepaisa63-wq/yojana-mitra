package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ApplicationEntity
import com.example.data.model.Scheme
import com.example.data.repository.SchemeIndex
import com.example.ui.viewmodel.YojanaViewModel
import com.example.ui.viewmodel.ChatUiState
import com.example.ui.viewmodel.SupportTicket
import com.example.ui.viewmodel.NotificationItem
import com.example.ui.viewmodel.PaymentTransaction
import kotlinx.coroutines.launch

// --- Global Color Tokens matching YojanaMitra Spec ---
val GreenPrimary = Color(0xFF005AC1) // Sleek primary branding blue
val GreenContainer = Color(0xFF005AC1) // Align with branding blue
val GreenOnContainer = Color(0xFFFFFFFF) // High contrast white
val SaffronSecondary = Color(0xFF005AC1) // Align with Sleek branding blue
val SaffronContainer = Color(0xFFDDE1FF) // Sleek active theme container (light blue/lavender)
val SaffronOnContainer = Color(0xFF001D3E) // Dark bold blue contrast text inside Active cards
val SurfaceBg = Color(0xFFFEFBFF) // Sleek crisp light-gray surface background
val SurfaceCard = Color(0xFFFFFFFF) // Clean card template
val TextNavy = Color(0xFF1B1B1F) // Sleek charcoal typography
val TextGray = Color(0xFF44474E) // Sleek muted outline text
val OutlineColor = Color(0xFFC4C6D0) // Modern sleek boundary gray border
val NavyAccent = Color(0xFFDDE1FF) // Sleek active item backdrops / lavender accent

@Composable
fun YojanaAppContent(viewModel: YojanaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isHindi = userProfile.languagePreference == "Hindi"

    Scaffold(
        topBar = {
            YojanaTopBar(
                isHindi = isHindi,
                onLanguageToggle = { viewModel.toggleLanguage() },
                onMenuClick = { viewModel.navigateTo("profile") }
            )
        },
        bottomBar = {
            YojanaBottomBar(
                currentScreen = currentScreen,
                isHindi = isHindi,
                onNavClick = { screen -> viewModel.navigateTo(screen) }
            )
        },
        floatingActionButton = {
            if (currentScreen != "chat_assistant") {
                FloatingActionButton(
                    onClick = { viewModel.navigateTo("chat_assistant") },
                    containerColor = GreenPrimary,
                    contentColor = Color.White,
                    modifier = Modifier
                        .padding(bottom = 16.dp)
                        .testTag("chat_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = "AI Assistant"
                    )
                }
            }
        },
        containerColor = SurfaceBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "home" -> HomeScreen(viewModel, isHindi)
                "schemes_list" -> SchemesListScreen(viewModel, isHindi)
                "scheme_detail" -> SchemeDetailScreen(viewModel, isHindi)
                "ai_finder" -> AiFinderScreen(viewModel, isHindi)
                "dashboard" -> DashboardScreen(viewModel, isHindi)
                "profile" -> ProfileScreen(viewModel, isHindi)
                "chat_assistant" -> ChatAssistantScreen(viewModel, isHindi)
                "payment" -> PaymentScreen(viewModel, isHindi)
                "apply_scheme" -> ApplySchemeScreen(viewModel, isHindi)
                "assisted_apply_flow" -> AssistedApplyFlowScreen(viewModel, isHindi)
                "track_application" -> TrackApplicationScreen(viewModel, isHindi)
                "admin_panel" -> AdminPanelScreen(viewModel, isHindi)
                else -> HomeScreen(viewModel, isHindi)
            }
        }
    }
}

// --- Top Global Action Bar ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YojanaTopBar(
    isHindi: Boolean,
    onLanguageToggle: () -> Unit,
    onMenuClick: () -> Unit
) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(GreenPrimary, shape = RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Y",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (isHindi) "योजनामित्र" else "YojanaMitra",
                        color = TextNavy,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.testTag("app_logo")
                    )
                    Text(
                        text = if (isHindi) "सरकारी सहायता पोर्टल" else "GOVT ASSISTANCE PORTAL",
                        color = TextGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        },
        actions = {
            TextButton(
                onClick = onLanguageToggle,
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("lang_toggle")
            ) {
                Text(
                    text = if (isHindi) "English" else "हिन्दी",
                    color = GreenPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier.testTag("profile_top_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Profile",
                    tint = GreenPrimary
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = SurfaceBg,
            titleContentColor = TextNavy
        ),
        modifier = Modifier.border(width = 1.dp, color = OutlineColor.copy(alpha = 0.2f))
    )
}

// --- Bottom Action Navigation ---
@Composable
fun YojanaBottomBar(
    currentScreen: String,
    isHindi: Boolean,
    onNavClick: (String) -> Unit
) {
    NavigationBar(
        containerColor = Color(0xFFF3F3FA),
        contentColor = TextNavy,
        tonalElevation = 0.dp,
        modifier = Modifier.border(width = 1.dp, color = OutlineColor.copy(alpha = 0.15f))
    ) {
        val homeActive = currentScreen == "home" || currentScreen == "ai_finder"
        NavigationBarItem(
            selected = homeActive,
            onClick = { onNavClick("home") },
            label = { Text(if (isHindi) "मुख्य" else "Home", fontWeight = if (homeActive) FontWeight.Bold else FontWeight.Normal) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Home"
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GreenPrimary,
                selectedTextColor = TextNavy,
                indicatorColor = NavyAccent,
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_home")
        )

        val schemesActive = currentScreen == "schemes_list" || currentScreen == "scheme_detail"
        NavigationBarItem(
            selected = schemesActive,
            onClick = { onNavClick("schemes_list") },
            label = { Text(if (isHindi) "योजनाएं" else "Schemes", fontWeight = if (schemesActive) FontWeight.Bold else FontWeight.Normal) },
            icon = {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.List,
                    contentDescription = "Schemes"
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GreenPrimary,
                selectedTextColor = TextNavy,
                indicatorColor = NavyAccent,
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_schemes")
        )

        val activeDashboard = currentScreen == "dashboard" || currentScreen == "payment"
        NavigationBarItem(
            selected = activeDashboard,
            onClick = { onNavClick("dashboard") },
            label = { Text(if (isHindi) "मेरे आवेदन" else "My Schemes", fontWeight = if (activeDashboard) FontWeight.Bold else FontWeight.Normal) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Assignment,
                    contentDescription = "Dashboard"
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GreenPrimary,
                selectedTextColor = TextNavy,
                indicatorColor = NavyAccent,
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_dashboard")
        )

        val activeProfile = currentScreen == "profile"
        NavigationBarItem(
            selected = activeProfile,
            onClick = { onNavClick("profile") },
            label = { Text(if (isHindi) "प्रोफ़ाइल" else "Profile", fontWeight = if (activeProfile) FontWeight.Bold else FontWeight.Normal) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Profile"
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = GreenPrimary,
                selectedTextColor = TextNavy,
                indicatorColor = NavyAccent,
                unselectedIconColor = TextGray,
                unselectedTextColor = TextGray
            ),
            modifier = Modifier.testTag("nav_profile")
        )
    }
}

// ==========================================
// SCREEN 1: HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header & Visual Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                GreenPrimary,
                                GreenContainer
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                // Background icon accent
                Icon(
                    imageVector = Icons.Default.AccountBalance,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier
                        .size(150.dp)
                        .align(Alignment.CenterEnd)
                )

                Column(
                    modifier = Modifier.fillMaxHeight(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isHindi) "नमस्ते, ${userProfile.name}!" else "Namaste, ${userProfile.name}!",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isHindi) "आपकी कौन सी सरकारी योजना में सहायता करें?" else "Which government scheme should we assist you with?",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 14.sp
                        )
                    }

                    // Direct Search Bar
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            viewModel.navigateTo("schemes_list")
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color.Gray
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isHindi) "योजना खोजें (e.g. Kisan, Student)..." else "Search schemes (e.g. Kisan, Student)...",
                                color = Color.Gray,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Popular Categories / श्रेणियाँ
        item {
            Column {
                Text(
                    text = if (isHindi) "श्रेणियाँ (Categories)" else "Categories",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextNavy,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CategoryItem(
                        title = "Farmer",
                        titleHindi = "किसान",
                        icon = Icons.Default.Agriculture,
                        color = SaffronContainer.copy(alpha = 0.15f),
                        iconColor = SaffronSecondary,
                        onClick = {
                            viewModel.selectCategory("Agriculture")
                            viewModel.navigateTo("schemes_list")
                        }
                    )
                    CategoryItem(
                        title = "Student",
                        titleHindi = "छात्र",
                        icon = Icons.Default.School,
                        color = NavyAccent.copy(alpha = 0.15f),
                        iconColor = NavyAccent,
                        onClick = {
                            viewModel.selectCategory("Education")
                            viewModel.navigateTo("schemes_list")
                        }
                    )
                    CategoryItem(
                        title = "Women",
                        titleHindi = "महिला",
                        icon = Icons.Default.Face,
                        color = Color.Magenta.copy(alpha = 0.08f),
                        iconColor = Color.Magenta,
                        onClick = {
                            viewModel.selectCategory("Women & Child")
                            viewModel.navigateTo("schemes_list")
                        }
                    )
                    CategoryItem(
                        title = "Business",
                        titleHindi = "व्यवसाय",
                        icon = Icons.Default.BusinessCenter,
                        color = Color.Cyan.copy(alpha = 0.1f),
                        iconColor = Color.Blue,
                        onClick = {
                            viewModel.selectCategory("Business")
                            viewModel.navigateTo("schemes_list")
                        }
                    )
                    CategoryItem(
                        title = "General",
                        titleHindi = "सामान्य",
                        icon = Icons.Default.Description,
                        color = GreenPrimary.copy(alpha = 0.1f),
                        iconColor = GreenPrimary,
                        onClick = {
                            viewModel.selectCategory("generally")
                            viewModel.navigateTo("schemes_list")
                        }
                    )
                }
            }
        }

        // AI Smart Scheme Finder Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_finder_cta"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NavyAccent)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "AI",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isHindi) "AI योजना खोजक" else "AI Scheme Finder",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = if (isHindi) "अपनी पात्रता के अनुसार सर्वोत्तम योजना खोजें" else "Find best active schemes matching your credentials",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.resetFinder()
                            viewModel.navigateTo("ai_finder")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("start_ai_finder_btn")
                    ) {
                        Text(
                            text = if (isHindi) "प्रारंभ" else "Start",
                            color = NavyAccent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Featured Schemes Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isHindi) "प्रमुख योजनाएं (Featured)" else "Featured Schemes",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextNavy
                )
                TextButton(
                    onClick = {
                        viewModel.selectCategory("All")
                        viewModel.navigateTo("schemes_list")
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = GreenPrimary)
                ) {
                    Text(if (isHindi) "सभी देखें" else "View All")
                }
            }
        }

        // Preseed Schemes list
        items(SchemeIndex.schemes.take(3)) { scheme ->
            SchemeListItemCard(
                scheme = scheme,
                isHindi = isHindi,
                onClick = {
                    viewModel.viewSchemeDetails(scheme.id)
                }
            )
        }

        // Language block visual
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SaffronSecondary.copy(alpha = 0.08f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "भाषा अब बाधा नहीं है" else "Language is no longer a barrier",
                        fontWeight = FontWeight.Bold,
                        color = SaffronSecondary,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (isHindi) "योजनामित्र आपके लिए हिंदी और अंग्रेजी दोनों में उपलब्ध है।" else "YojanaMitra is fully configured in both English and Hindi for citizen empathy.",
                        fontSize = 12.sp,
                        color = TextNavy.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryItem(
    title: String,
    titleHindi: String,
    icon: ImageVector,
    color: Color,
    iconColor: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(90.0.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                color = TextNavy,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = titleHindi,
                fontSize = 10.sp,
                color = TextGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SchemeListItemCard(
    scheme: Scheme,
    isHindi: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("scheme_card_${scheme.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.4f))
    ) {
        Column {
            // Title & Accent block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                GreenPrimary.copy(alpha = 0.05f),
                                NavyAccent.copy(alpha = 0.05f)
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (scheme.category.equals("generally", ignoreCase = true)) {
                            if (isHindi) "सामान्य व दस्तावेज़" else "General & Documents"
                        } else {
                            scheme.category
                        },
                        color = GreenPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(
                                GreenPrimary.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )

                    Text(
                        text = scheme.badge,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .background(SaffronContainer, shape = RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Description block
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isHindi) scheme.titleHindi else scheme.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = TextNavy
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isHindi) scheme.descriptionHindi else scheme.description,
                    fontSize = 13.sp,
                    color = TextGray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Divider(color = OutlineColor.copy(alpha = 0.3f))

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = GreenPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = scheme.fundingType,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextNavy
                        )
                    }

                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isHindi) "विवरण देखें" else "View Details",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 2: ALL SCHEMES LIST
// ==========================================
@Composable
fun SchemesListScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val filteredSchemes by viewModel.filteredSchemes.collectAsStateWithLifecycle()

    val categories = listOf("All", "generally", "Agriculture", "Health", "Housing", "Education", "Women & Child", "Employment", "Business")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        // Search & Input Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(0.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text(if (isHindi) "योजना का नाम खोजें..." else "Search scheme name...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = null)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GreenPrimary,
                        unfocusedBorderColor = OutlineColor
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Scrollable categories row
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { category ->
                        val active = selectedCategory.equals(category, ignoreCase = true)
                        val labelText = when {
                            category.equals("generally", ignoreCase = true) -> if (isHindi) "सामान्य व दस्तावेज़" else "General & Documents"
                            category.equals("All", ignoreCase = true) -> if (isHindi) "सभी" else "All"
                            else -> category
                        }
                        FilterChip(
                            selected = active,
                            onClick = { viewModel.selectCategory(category) },
                            label = { Text(labelText) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GreenPrimary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("cat_chip_$category")
                        )
                    }
                }
            }
        }

        // Scheme items list
        if (filteredSchemes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        modifier = Modifier.size(60.dp),
                        tint = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isHindi) "कोई योजना नहीं मिली" else "No matching schemes found",
                        fontWeight = FontWeight.Bold,
                        color = TextNavy
                    )
                    Text(
                        text = if (isHindi) "कृपया अन्य खोज नाम का प्रयास करें।" else "Please adjust your keywords or category filter.",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredSchemes) { scheme ->
                    SchemeListItemCard(
                        scheme = scheme,
                        isHindi = isHindi,
                        onClick = {
                            viewModel.viewSchemeDetails(scheme.id)
                        }
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 3: SCHEME DETAILS SCREEN
// ==========================================
@Composable
fun SchemeDetailScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val selectedId by viewModel.selectedSchemeId.collectAsStateWithLifecycle()
    val scheme = selectedId?.let { SchemeIndex.getSchemeById(it) }

    if (scheme == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (isHindi) "योजना विवरण उपलब्ध नहीं है" else "Scheme detail not found.")
        }
        return
    }

    // Toggle expanded FAQ indexes
    val expandedFaqIndices = remember { mutableStateMapOf<Int, Boolean>() }
    var eligibilityCheckResult by remember { mutableStateOf<String?>(null) } // null, "Eligible", "NotEligible"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Back Header Button
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                onClick = { viewModel.navigateTo("schemes_list") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("detail_back_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = GreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHindi) "वापस जाएं (Back)" else "Back to Schemes",
                        color = GreenPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Scheme Hero Summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GreenPrimary),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = scheme.category.uppercase(),
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHindi) scheme.titleHindi else scheme.title,
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 28.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isHindi) scheme.descriptionHindi else scheme.description,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Payments, contentDescription = null, tint = Color.White)
                                Text(scheme.fundingType, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(Color.White.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Event, contentDescription = null, tint = Color.White)
                                Text(scheme.frequency, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Scheme Benefits Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = GreenPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isHindi) "योजना के लाभ (Benefits)" else "Scheme Benefits",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = TextNavy
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    val activeBenefits = if (isHindi) scheme.benefitsHindi else scheme.benefits
                    activeBenefits.forEach { benefit ->
                        Row(
                            modifier = Modifier.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = GreenPrimary,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = benefit,
                                fontSize = 13.sp,
                                color = TextNavy,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // Eligibility Card (Green Block visual matching HTML mockup)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = GreenPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "योग्यता मानदंड (Eligibility)" else "Eligibility Criteria",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val matchTags = if (isHindi) scheme.eligibilityHindiMatches else scheme.eligibilityMatches
                    matchTags.forEach { rule ->
                        Row(modifier = Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(rule, color = Color.White, fontSize = 13.sp)
                        }
                    }

                    val exclTags = if (isHindi) scheme.eligibilityHindiExclusions else scheme.eligibilityExclusions
                    exclTags.forEach { rule ->
                        Row(modifier = Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(rule, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, textDecoration = TextDecoration.LineThrough)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Instant check helper
                    Button(
                        onClick = {
                            // Quick simulate eligibility match based on simple rule match
                            eligibilityCheckResult = "Eligible"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("eligibility_check_now_btn")
                    ) {
                        Text(
                            text = if (isHindi) "योग्यता की जांच करें (Check Now)" else "Check Eligibility Instantly",
                            color = GreenPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    eligibilityCheckResult?.let { result ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isHindi) "✓ बधाई हो! आप प्राथमिक मानदंडों के आधार पर पात्र लग रहे हैं।" else "✓ Congratulations! You seem fully eligible based on primary matches.",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Required Documents checklist
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "आवश्यक दस्तावेज चेकलिस्ट (Required Documents)" else "Required Documents Checklist",
                        fontWeight = FontWeight.Bold,
                        color = TextNavy,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val docItems = if (isHindi) scheme.requiredDocumentsHindi else scheme.requiredDocuments
                    docItems.forEach { doc ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .background(SurfaceBg, shape = RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = SaffronContainer)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(doc, fontSize = 12.sp, color = TextNavy, modifier = Modifier.weight(1f))
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = GreenPrimary)
                        }
                    }
                }
            }
        }

        // Apply actions / CTAs
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SaffronSecondary.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "योजना के लिए आवेदन करने के लिए तैयार हैं?" else "Ready to Apply for this Scheme?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SaffronSecondary
                    )
                    Text(
                        text = if (isHindi) "आप स्वयं मुफ्त में आवेदन कर सकते हैं या हमारे विशेषज्ञ की सहायता ले सकते हैं।" else "Apply by yourself easily for free or obtain guided specialist executive assistance.",
                        fontSize = 12.sp,
                        color = TextNavy
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.startAssistedApplyFlow(scheme.id)
                                viewModel.navigateTo("apply_scheme")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, GreenPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("apply_self_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Launch, contentDescription = null, tint = GreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isHindi) "स्वयं आवेदन करें (मुफ्त)" else "Apply Yourself (Free)",
                                color = GreenPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                viewModel.startAssistedApplyFlow(scheme.id)
                                viewModel.navigateTo("apply_scheme")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("apply_expert_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.SupportAgent, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isHindi) "विशेषज्ञ सहायता प्राप्त करें (सशुल्क)" else "Get Expert Help (Paid Assisted)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // FAQs Accordeons (Directly interactive matching requested mockups)
        item {
            Text(
                text = if (isHindi) "अक्सर पूछे जाने वाले प्रश्न (FAQs)" else "Frequently Asked Questions",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextNavy,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(scheme.faqList.size) { i ->
            val faq = scheme.faqList[i]
            val isExpanded = expandedFaqIndices[i] ?: false

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedFaqIndices[i] = !isExpanded }
                    .testTag("faq_item_$i"),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isHindi) faq.questionHindi else faq.question,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextNavy,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = GreenPrimary
                        )
                    }

                    if (isExpanded) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = OutlineColor.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isHindi) faq.answerHindi else faq.answer,
                            fontSize = 12.sp,
                            color = TextGray,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 4: AI SMART FINDER QUESTIONNAIRE
// ==========================================
@Composable
fun AiFinderScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val currentStep by viewModel.finderStep.collectAsStateWithLifecycle()
    val answers by viewModel.answers.collectAsStateWithLifecycle()

    val totalSteps = 4

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Step indicator row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isHindi) "चरण $currentStep / $totalSteps" else "Step $currentStep / $totalSteps",
                fontWeight = FontWeight.Bold,
                color = GreenPrimary,
                fontSize = 15.sp,
                modifier = Modifier
                    .background(GreenPrimary.copy(alpha = 0.08f), shape = RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )

            Text(
                text = if (isHindi) "कुछ सवालों के बाद योजना मिल जाएगी!" else "Matched schemes loading upon answering!",
                fontSize = 11.sp,
                color = TextGray,
                fontWeight = FontWeight.Medium
            )
        }

        LinearProgressIndicator(
            progress = { currentStep.toFloat() / totalSteps },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(CircleShape),
            color = GreenContainer,
            trackColor = OutlineColor.copy(alpha = 0.5f)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Step Content Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("survey_card"),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (currentStep) {
                    1 -> {
                        item {
                            Text(
                                text = if (isHindi) "आपकी व्यक्तिगत जानकारी (Age)" else "What is your Age?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextNavy
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = answers.age,
                                onValueChange = { viewModel.updateAnswers { a -> a.copy(age = it) } },
                                label = { Text(if (isHindi) "उम्र (वर्षों में)" else "Enter your age") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("finder_age_input"),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GreenPrimary,
                                    unfocusedBorderColor = OutlineColor
                                )
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            Text(
                                text = if (isHindi) "आपका लिंग (Gender)" else "What is your Gender?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextNavy
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val genders = listOf("Male", "Female", "Other")
                                genders.forEach { g ->
                                    val active = answers.gender == g
                                    Button(
                                        onClick = { viewModel.updateAnswers { a -> a.copy(gender = g) } },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (active) GreenPrimary else Color.White
                                        ),
                                        border = BorderStroke(1.dp, if (active) GreenPrimary else OutlineColor),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(text = g, color = if (active) Color.White else TextNavy, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        item {
                            Text(
                                text = if (isHindi) "आपका राज्य कौन सा है? (State)" else "Select your State",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextNavy
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            val states = listOf("Uttar Pradesh", "Bihar", "Madhya Pradesh", "Rajasthan", "Maharashtra", "Other")
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                states.forEach { s ->
                                    val active = answers.state == s
                                    Button(
                                        onClick = { viewModel.updateAnswers { a -> a.copy(state = s) } },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (active) GreenPrimary else Color.White
                                        ),
                                        border = BorderStroke(1.dp, if (active) GreenPrimary else OutlineColor),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = s, color = if (active) Color.White else TextNavy)
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        item {
                            Text(
                                text = if (isHindi) "आपकी वार्षिक आय कितनी है? (Annual Income)" else "Specify your annual household income",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextNavy
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            val incomes = listOf(
                                "l1" to (if (isHindi) "₹1,00,000 से कम (Less than 1L)" else "Less than ₹1,00,000"),
                                "l2" to (if (isHindi) "₹1,00,000 - ₹2,50,000" else "₹1,00,000 - ₹2,50,000"),
                                "l3" to (if (isHindi) "₹2,50,000 - ₹5,00,000" else "₹2,50,000 - ₹5,00,000"),
                                "l4" to (if (isHindi) "₹5,00,000 से अधिक" else "More than ₹5,00,000")
                            )

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                incomes.forEach { (key, label) ->
                                    val active = answers.annualIncome == key
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.updateAnswers { a -> a.copy(annualIncome = key) } }
                                            .border(
                                                1.dp,
                                                if (active) GreenPrimary else OutlineColor,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = active,
                                            onClick = { viewModel.updateAnswers { a -> a.copy(annualIncome = key) } },
                                            colors = RadioButtonDefaults.colors(selectedColor = GreenPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = label, fontSize = 13.sp, color = TextNavy)
                                    }
                                }
                            }
                        }
                    }
                    4 -> {
                        item {
                            Text(
                                text = if (isHindi) "आपका मुख्य व्यवसाय क्या है? (Occupation)" else "What is your main Occupation?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextNavy
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            val occupations = listOf("Farmer", "Student", "Women", "Retired", "MSME Business")
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                occupations.forEach { occ ->
                                    val active = answers.occupation == occ
                                    Button(
                                        onClick = { viewModel.updateAnswers { a -> a.copy(occupation = occ) } },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (active) GreenPrimary else Color.White
                                        ),
                                        border = BorderStroke(1.dp, if (active) GreenPrimary else OutlineColor),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(text = occ, color = if (active) Color.White else TextNavy)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateAnswers { a -> a.copy(isDisabled = !answers.isDisabled) }
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = answers.isDisabled,
                                    onCheckedChange = {
                                        viewModel.updateAnswers { a -> a.copy(isDisabled = it) }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = GreenPrimary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isHindi) "विकलांगता प्रमाण पत्र है (Disabled / PwD Status)" else "Do you have physical PwD / disability certification?",
                                    fontSize = 12.sp,
                                    color = TextNavy
                                )
                            }
                        }
                    }
                }
            }
        }

        // Stepper actions at bottom
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { viewModel.prevFinderStep() },
                enabled = currentStep > 1,
                colors = ButtonDefaults.buttonColors(containerColor = OutlineColor.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("finder_prev_btn")
            ) {
                Text(
                    text = if (isHindi) "पिछला" else "Back",
                    color = TextNavy
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Button(
                onClick = { viewModel.nextFinderStep() },
                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1.5f)
                    .testTag("finder_next_btn")
            ) {
                Text(
                    text = if (currentStep == totalSteps) {
                        if (isHindi) "योजनाएं खोजें" else "Submit Finder"
                    } else {
                        if (isHindi) "अगला" else "Next"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Safety statement
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = GreenPrimary.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(16.dp))
                Text(
                    text = if (isHindi) "आपका डेटा पूरी तरह से सुरक्षित है।" else "Your profile coordinates are encrypted and safe.",
                    fontSize = 10.sp,
                    color = TextNavy
                )
            }
        }
    }
}

// ==========================================
// SCREEN 5: ASSISTED SERVICE PAYMENT SIMULATION
// ==========================================
@Composable
fun PaymentScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val tempSchemeId by viewModel.tempPaymentSchemeId.collectAsStateWithLifecycle()
    val tempServiceType by viewModel.tempPaymentServiceType.collectAsStateWithLifecycle()

    val scheme = tempSchemeId?.let { SchemeIndex.getSchemeById(it) }

    if (scheme == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(if (isHindi) "कोई भुगतान लंबित नहीं है" else "No pending payment found.")
        }
        return
    }

    val price = if (tempServiceType == "premium") 499 else 199
    var selectedPaymentMethod by remember { mutableStateOf("upi") } // upi, wallet, card
    var paymentCompleted by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (isHindi) "सशुल्क विशेषज्ञ सहायता (Payment Checkout)" else "Assistance Checkout",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextNavy
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "योजना:" else "Scheme:",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                    Text(
                        text = if (isHindi) scheme.titleHindi else scheme.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TextNavy
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isHindi) "सहायता शुल्क (Service Type)" else "Service Assistance Type",
                            fontSize = 13.sp,
                            color = TextNavy
                        )
                        Text(
                            text = if (tempServiceType == "premium") "Premium Assistance" else "Basic Guidance Assistance",
                            fontWeight = FontWeight.Bold,
                            color = GreenPrimary,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Divider(color = OutlineColor.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isHindi) "कुल भुगतान" else "Total Amount Payable",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextNavy
                        )
                        Text(
                            text = "₹$price",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = GreenPrimary
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = if (isHindi) "भुगतान विधि चुनें (Payment Method)" else "Select Payment Method",
                fontWeight = FontWeight.Bold,
                color = TextNavy
            )
        }

        // Custom simulated Payments checkboxes
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "upi" to "UPI (GooglePay, PhonePe, Paytm)",
                    "card" to (if (isHindi) "क्रेडिट / डेबिट कार्ड" else "Debit / Credit Card")
                ).forEach { (id, label) ->
                    val active = selectedPaymentMethod == id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPaymentMethod = id }
                            .background(Color.White, shape = RoundedCornerShape(8.dp))
                            .border(
                                1.dp,
                                if (active) GreenPrimary else OutlineColor.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = active,
                            onClick = { selectedPaymentMethod = id },
                            colors = RadioButtonDefaults.colors(selectedColor = GreenPrimary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = TextNavy)
                    }
                }
            }
        }

        item {
            if (paymentCompleted) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GreenPrimary.copy(alpha = 0.12f), shape = RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isHindi) "भुगतान सफल रहा!" else "Payment Successful!",
                            fontWeight = FontWeight.Bold,
                            color = GreenPrimary
                        )
                        Button(
                            onClick = {
                                viewModel.completePaymentAndSubmit(scheme.requiredDocuments)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier
                                .padding(top = 12.dp)
                                .testTag("payment_verify_btn")
                        ) {
                            Text("Go to Dashboard", color = Color.White)
                        }
                    }
                }
            } else {
                Button(
                    onClick = { paymentCompleted = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulate_pay_btn"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = if (isHindi) "₹$price का सुरक्षित भुगतान करें" else "Proceed Security Pay of ₹$price",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 6: USER TRACKING DASHBOARD & MISSING DOCUMENT UPLOADER
// ==========================================
@Composable
fun DashboardScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val applications by viewModel.allApplications.collectAsStateWithLifecycle()
    var selectedAppToUpload by remember { mutableStateOf<ApplicationEntity?>(null) } // null if dialog closed

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isHindi) "आवेदन ट्रैकर (Dashboard)" else "Application Tracker",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextNavy
                )

                Box(
                    modifier = Modifier
                        .background(GreenPrimary.copy(alpha = 0.1f), shape = CircleShape)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("KYC Verified", color = GreenPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (applications.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(Color.White, shape = RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(if (isHindi) "कोई सक्रिय आवेदन नहीं है।" else "No active scheme applications.")
                        Button(
                            onClick = { viewModel.navigateTo("home") },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier.padding(top = 12.dp)
                        ) {
                            Text("Apply for Schemes", color = Color.White)
                        }
                    }
                }
            }
        } else {
            items(applications) { app ->
                DashboardAppItemCard(
                    app = app,
                    isHindi = isHindi,
                    onUploadMissing = { selectedAppToUpload = app },
                    onDelete = { viewModel.deleteApplicationById(app.id) }
                )
            }
        }

        // Notifications column placeholder style
        item {
            Text(
                text = if (isHindi) "समाचार और सूचनाएं (What's New)" else "What's New",
                fontWeight = FontWeight.Bold,
                color = TextNavy,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "• New: PM Vishwakarma Yojana registration is officially unlocked for traditional craftspeople.",
                        fontSize = 12.sp,
                        color = TextNavy
                    )
                    Text(
                        text = "• Land Verification alert: Revenue department is running direct audits for PM Kisan beneficiaries.",
                        fontSize = 12.sp,
                        color = TextNavy
                    )
                }
            }
        }
    }

    // Document upload simulation dialog
    selectedAppToUpload?.let { app ->
        AlertDialog(
            onDismissRequest = { selectedAppToUpload = null },
            title = {
                Text(
                    text = if (isHindi) "अपलोड करें: ${app.schemeTitle}" else "Upload: ${app.schemeTitle}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = if (isHindi) "कृपया निम्नलिखित गुमशुदा दस्तावेज़ अपलोड करें:" else "Please upload structural missing files:",
                        fontSize = 13.sp,
                        color = TextNavy
                    )
                    Text(
                        text = app.missingDocuments,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = SaffronSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Buttons representing fake uploaders
                    Button(
                        onClick = {
                            viewModel.updateApplication(
                                app.copy(
                                    status = "Form Submitted",
                                    statusDetails = "All missing documents received. YojanaMitra Executive is reviewing verification status.",
                                    uploadedDocuments = app.missingDocuments, // Simulate complete upload
                                    missingDocuments = "None"
                                )
                            )
                            selectedAppToUpload = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("upload_camera_simulate_btn")
                    ) {
                        Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Simulate Camera Scan / Upload File")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedAppToUpload = null }) {
                    Text("Close", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun DashboardAppItemCard(
    app: ApplicationEntity,
    isHindi: Boolean,
    onUploadMissing: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_item_${app.schemeId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Category & Date
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = app.schemeCategory.uppercase(),
                    color = GreenPrimary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Applied: ${app.appliedDate}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = onDelete, modifier = Modifier.size(18.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = app.schemeTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextNavy
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Stepper Visuals matching mockups
            val stepIndex = when (app.status) {
                "Documents Pending" -> 1
                "Form Submitted" -> 2
                "Under Review" -> 3
                "Approved" -> 4
                else -> 1
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StepPoint(label = "Docs Pending", active = stepIndex >= 1, done = stepIndex > 1)
                Divider(modifier = Modifier.weight(1f).height(2.dp).background(if (stepIndex >= 2) GreenPrimary else Color.LightGray))
                StepPoint(label = "Submitted", active = stepIndex >= 2, done = stepIndex > 2)
                Divider(modifier = Modifier.weight(1f).height(2.dp).background(if (stepIndex >= 3) GreenPrimary else Color.LightGray))
                StepPoint(label = "In Review", active = stepIndex >= 3, done = stepIndex > 3)
                Divider(modifier = Modifier.weight(1f).height(2.dp).background(if (stepIndex >= 4) GreenPrimary else Color.LightGray))
                StepPoint(label = "Approved", active = stepIndex >= 4, done = stepIndex > 4)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details warning card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (app.status == "Documents Pending") Color(0xFFFFDAD6) else SaffronContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (app.status == "Documents Pending") Icons.Default.Warning else Icons.Default.Info,
                        contentDescription = null,
                        tint = if (app.status == "Documents Pending") Color(0xFFBA1A1A) else GreenPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = app.statusDetails,
                            fontSize = 12.sp,
                            color = if (app.status == "Documents Pending") Color(0xFF410002) else SaffronOnContainer,
                            lineHeight = 16.sp,
                            fontWeight = FontWeight.Medium
                        )

                        if (app.status == "Documents Pending") {
                            Text(
                                text = "Missing Documents: ${app.missingDocuments}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFBA1A1A),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            // Upload actions if pending
            if (app.status == "Documents Pending") {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onUploadMissing,
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_missing_docs_btn")
                ) {
                    Icon(imageVector = Icons.Default.UploadFile, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isHindi) "गुमशुदा दस्तावेज़ अपलोड करें" else "Upload Missing Documents")
                }
            }
        }
    }
}

@Composable
fun StepPoint(label: String, active: Boolean, done: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(
                    if (done) GreenPrimary else if (active) SaffronContainer else Color.LightGray
                ),
            contentAlignment = Alignment.Center
        ) {
            if (done) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
            } else {
                Text(
                    text = if (active) "✏" else "•",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (active) TextNavy else Color.Gray,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// ==========================================
// SCREEN 7: AI CHAT ASSISTANT
// ==========================================
@Composable
fun ChatAssistantScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val chatState by viewModel.chatUiState.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        // Chat Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(0.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isHindi) "योजनामित्र AI सहायक" else "YojanaMitra AI Counselor",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = GreenPrimary
                    )
                    Text(
                        text = if (isHindi) "सरकारी योजना संबंधित प्रश्न पूछें" else "Ask anything regarding schemes",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                IconButton(
                    onClick = { viewModel.clearHistory() },
                    modifier = Modifier.testTag("clear_chat_btn")
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear Chat", tint = Color.LightGray)
                }
            }
        }

        // Messages Box
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            // First greeting message always visible
            item {
                ChatBubble(
                    sender = "ai",
                    message = if (isHindi) {
                        "नमस्कार! मैं आपका डिजिटल योजनामित्र हूँ। मैं आपको सरकारी योजनाओं की जानकारी, योग्यता परीक्षण और आवेदन करने में मदद करूँगा। कृपया अपना प्रश्न पूछें!"
                    } else {
                        "Namaste! I am your digital YojanaMitra AI assistant. Ask me anything about crop subsidies, scholarships, business loans, or gas connections."
                    }
                )
            }

            items(messages) { msg ->
                ChatBubble(sender = msg.sender, message = msg.message)
            }

            if (chatState is ChatUiState.Loading) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.CenterStart) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = GreenPrimary)
                    }
                }
            }
        }

        // Input bottom bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(0.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text(if (isHindi) "अपना प्रश्न यहाँ लिखें..." else "Write user message here...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GreenPrimary,
                        unfocusedBorderColor = OutlineColor
                    )
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        val prompt = textInput
                        if (prompt.trim().isNotEmpty()) {
                            viewModel.postChatMessage(prompt)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .background(GreenPrimary, shape = CircleShape)
                        .testTag("chat_send_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ChatBubble(sender: String, message: String) {
    val isBot = sender == "ai"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isBot) Arrangement.Start else Arrangement.End
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isBot) Color(0xFFE6F3E6) else GreenPrimary
            ),
            shape = RoundedCornerShape(
                topStart = 12.dp,
                topEnd = 12.dp,
                bottomStart = if (isBot) 0.dp else 12.dp,
                bottomEnd = if (isBot) 12.dp else 0.dp
            ),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = message,
                fontSize = 13.sp,
                color = if (isBot) TextNavy else Color.White,
                modifier = Modifier.padding(12.dp),
                lineHeight = 18.sp
            )
        }
    }
}

// ==========================================
// SCREEN 8: USER PROFILE & SETTINGS
// ==========================================
@Composable
fun ProfileScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()

    var isEditing by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(profile.name) }
    var editState by remember { mutableStateOf(profile.state) }
    var editCity by remember { mutableStateOf(profile.city) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // User profile picture placeholder
        item {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(GreenPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = GreenPrimary,
                    modifier = Modifier.size(60.dp)
                )
            }
        }

        item {
            Text(
                text = profile.name,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = TextNavy
            )
        }

        item {
            Text(
                text = "Member since Oct 2023",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        // Settings items card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isHindi) "व्यक्तिगत विवरण" else "Personal Coordinates",
                        fontWeight = FontWeight.Bold,
                        color = TextNavy,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (isEditing) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editState,
                            onValueChange = { editState = it },
                            label = { Text("State") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = editCity,
                            onValueChange = { editCity = it },
                            label = { Text("City") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                viewModel.updateProfile(
                                    profile.copy(name = editName, state = editState, city = editCity)
                                )
                                isEditing = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Changes", color = Color.White)
                        }
                    } else {
                        Text("• Occupation: ${profile.occupation}", fontSize = 13.sp, color = TextGray)
                        Text("• Age: ${profile.age}", fontSize = 13.sp, color = TextGray)
                        Text("• State / Location: ${profile.state}", fontSize = 13.sp, color = TextGray)
                        Text("• City / Town: ${profile.city}", fontSize = 13.sp, color = TextGray)
                        Text("• Annual Income: ₹${profile.annualIncome}", fontSize = 13.sp, color = TextGray)

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                editName = profile.name
                                editState = profile.state
                                editCity = profile.city
                                isEditing = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Edit Details", color = Color.White)
                        }
                    }
                }
            }
        }

        // App options cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Language info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = GreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isHindi) "भाषा विकल्प (Language)" else "Active Language", fontSize = 13.sp, color = TextNavy)
                        }

                        Text(
                            text = if (isHindi) "हिन्दी (Hindi)" else "English",
                            fontWeight = FontWeight.Bold,
                            color = GreenPrimary,
                            fontSize = 13.sp
                        )
                    }

                    Divider(color = OutlineColor.copy(alpha = 0.3f))

                    // Track Application Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo("track_application") }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = GreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isHindi) "आवेदन ट्रैक करें (Track App)" else "Track Application (MFA)", fontSize = 13.sp, color = TextNavy)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }

                    Divider(color = OutlineColor.copy(alpha = 0.3f))

                    // Admin Portal Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.navigateTo("admin_panel") }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.SupervisorAccount, contentDescription = null, tint = GreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isHindi) "एडमिन पोर्टल (Admin Panel)" else "Admin Portal (Testing)", fontSize = 13.sp, color = TextNavy)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }

                    Divider(color = OutlineColor.copy(alpha = 0.3f))

                    // App version
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, tint = GreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(if (isHindi) "मदद और सहायता" else "Help & Support Support", fontSize = 13.sp, color = TextNavy)
                        }
                        Text("Version 1.4.2", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// ==========================================
// NEW SCREEN: APPLY OPTIONS (FREE SELF vs PAID EXPERT)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApplySchemeScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val selectedSchemeId by viewModel.tempPaymentSchemeId.collectAsStateWithLifecycle()
    val finalSchemeId = selectedSchemeId ?: "pm_kisan"
    val scheme = SchemeIndex.getSchemeById(finalSchemeId) ?: SchemeIndex.schemes.first()
    
    var showSelfApplyGuidelines by remember { mutableStateOf(false) }
    var selfApplyComplete by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        // App bar
        TopAppBar(
            title = { Text(if (isHindi) "आवेदन विकल्प" else "Choose Application Mode", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 18.sp) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateTo("scheme_detail") }) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextNavy)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Scheme context header
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GreenPrimary.copy(alpha = 0.08f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = scheme.category.uppercase(),
                            color = GreenPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isHindi) scheme.titleHindi else scheme.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = TextNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isHindi) scheme.descriptionHindi else scheme.description,
                            fontSize = 13.sp,
                            color = TextNavy.copy(alpha = 0.8f),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // OPTION 1: Apply Yourself (100% Free)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_free_card"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, if (showSelfApplyGuidelines) GreenPrimary else OutlineColor.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isHindi) "स्वयं आवेदन करें" else "Apply Yourself",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextNavy
                            )
                            Box(
                                modifier = Modifier
                                    .background(GreenPrimary.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isHindi) "100% मुफ्त" else "100% Free",
                                    color = GreenPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = if (isHindi) 
                                "बिना किसी सेवा शुल्क के सरकारी पोर्टल पर सीधे स्वयं आवेदन करें। हम आपको आवश्यक दस्तावेज और कदम प्रदान करते हैं।" 
                                else "Apply directly on the official government portal yourself. No service charges. We only provide guidance.",
                            fontSize = 13.sp,
                            color = TextGray,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showSelfApplyGuidelines = !showSelfApplyGuidelines },
                            colors = ButtonDefaults.buttonColors(containerColor = if (showSelfApplyGuidelines) Color.Gray else GreenPrimary),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (showSelfApplyGuidelines) 
                                    (if (isHindi) "दिशा-निर्देश छिपाएं" else "Hide Guidelines") 
                                    else (if (isHindi) "स्वयं आवेदन करें" else "Apply Yourself"),
                                color = Color.White
                            )
                        }

                        // Expanded Self-Apply Information Drawer
                        if (showSelfApplyGuidelines) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Divider(color = OutlineColor.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(12.dp))

                            // Checklist
                            Text(
                                text = if (isHindi) "☑ पात्रता चेकलिस्ट:" else "☑ Eligibility Checklist:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextNavy
                            )
                            scheme.benefits.take(2).forEach { benefit ->
                                Text("• $benefit", fontSize = 12.sp, color = TextGray, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Required Docs
                            Text(
                                text = if (isHindi) "📋 आवश्यक दस्तावेज़:" else "📋 Required Documents:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextNavy
                            )
                            scheme.requiredDocuments.forEach { doc ->
                                Text("• $doc", fontSize = 12.sp, color = TextGray, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Process
                            Text(
                                text = if (isHindi) "⚙ चरण-दर-चरण प्रक्रिया:" else "⚙ Step-by-Step Process:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextNavy
                            )
                            val steps = if (isHindi) {
                                listOf("1. आधिकारिक पोर्टल पर जाएं।", "2. 'न्यू रजिस्ट्रेशन' लिंक पर क्लिक करें।", "3. आधार विवरण दर्ज करें और ओटीपी सत्यापित करें।")
                            } else {
                                listOf("1. Go to official government yojana link.", "2. Click on 'New Registration' block.", "3. Fill personal fields & upload soft copies.")
                            }
                            steps.forEach { step ->
                                Text(step, fontSize = 12.sp, color = TextGray, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Important Instructions
                            Text(
                                text = if (isHindi) "⚠️ महत्वपूर्ण निर्देश:" else "⚠️ Important Instructions:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextNavy
                            )
                            Text(
                                text = if (isHindi) "कृपया सुनिश्चित करें कि आपका मोबाइल नंबर आधार कार्ड से लिंक है।" else "Please verify that your active mobile is linked with UIDAI Aadhaar database to complete OTP verification.",
                                fontSize = 12.sp,
                                color = Color.Red.copy(alpha = 0.8f),
                                lineHeight = 16.sp,
                                modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Official portal link
                            val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                            Button(
                                onClick = {
                                    uriHandler.openUri("https://www.india.gov.in/my-government/schemes")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Launch, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (isHindi) "सरकारी वेबसाइट खोलें (New Tab)" else "Official Government Apply Link", color = Color.White)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Disclaimer
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color.LightGray.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (isHindi) 
                                        "हम कोई आवेदन शुल्क नहीं लेते हैं। आप सीधे आधिकारिक सरकारी पोर्टल के माध्यम से आवेदन कर रहे हैं।" 
                                        else "We do not collect any application fees. You are applying directly through the official Government portal.",
                                    fontSize = 11.sp,
                                    color = Color.DarkGray,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Button to record self application
                            Button(
                                onClick = {
                                    viewModel.applyFreeSelf(scheme.id, scheme.requiredDocuments)
                                    selfApplyComplete = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isHindi) "स्वयं आवेदन दर्ज करें" else "Mark Self-Apply Completed", color = Color.White)
                            }
                        }
                    }
                }
            }

            // OPTION 2: Get Expert Help (Paid Assisted)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("option_paid_card"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, SaffronContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isHindi) "विशेषज्ञ सहायता प्राप्त करें" else "Get Expert Help",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextNavy
                            )
                            Box(
                                modifier = Modifier
                                    .background(SaffronContainer.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isHindi) "सहायता सेवा" else "Paid Assistance",
                                    color = SaffronSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isHindi) 
                                "हमारे विशेषज्ञ दस्तावेज सत्यापन और त्रुटि मुक्त फाइलिंग के साथ आपके आवेदन को सफलतापूर्वक भरने में मदद करते हैं।" 
                                else "Our experts help you complete your application correctly, handle verification queries, and reduce common rejection mistakes.",
                            fontSize = 13.sp,
                            color = TextGray,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                viewModel.startAssistedApplyFlow(scheme.id)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isHindi) "विशेषज्ञ सहायता शुरू करें" else "Get Expert Help", color = Color.White)
                        }
                    }
                }
            }

            // Core trust legal disclaimer
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isHindi) "⚠️ वैधानिक चेतावनी / अस्वीकरण" else "⚠️ Statutory Warning & Disclaimer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.Red.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isHindi) 
                                "यह आवेदन मार्गदर्शन और दस्तावेज सत्यापन के लिए एक सशुल्क सहायता सेवा है। हम सरकारी विभाग नहीं हैं। सरकारी योजनाओं के लाभ और स्वीकृति केवल संबंधित सरकारी प्राधिकरण द्वारा तय की जाती है।" 
                                else "This is a paid assistance service for application guidance and document verification. We are not a Government department. Government scheme benefits and approval are decided only by the concerned Government authority.",
                            fontSize = 11.sp,
                            color = TextGray,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }

    if (selfApplyComplete) {
        AlertDialog(
            onDismissRequest = { selfApplyComplete = false },
            title = { Text(if (isHindi) "सफलता!" else "Success!") },
            text = { Text(if (isHindi) "आपका स्व-आवेदन रिकॉर्ड दर्ज कर लिया गया है। आप इसे अपने डैशबोर्ड में देख सकते हैं।" else "Your free self-application tracker is saved successfully. You can track this in your dashboard.") },
            confirmButton = {
                TextButton(onClick = {
                    selfApplyComplete = false
                    viewModel.navigateTo("dashboard")
                }) {
                    Text("OK", color = GreenPrimary)
                }
            }
        )
    }
}

// ==========================================
// NEW SCREEN: MULTI-STEP ASSISTED FORM STEPPER FLOW
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistedApplyFlowScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val step by viewModel.applyFlowStep.collectAsStateWithLifecycle()
    val selectedSchemeId by viewModel.tempPaymentSchemeId.collectAsStateWithLifecycle()
    val finalSchemeId = selectedSchemeId ?: "pm_kisan"
    val scheme = SchemeIndex.getSchemeById(finalSchemeId) ?: SchemeIndex.schemes.first()

    // Form inputs collected
    val name by viewModel.formFullName.collectAsStateWithLifecycle()
    val mobile by viewModel.formMobile.collectAsStateWithLifecycle()
    val otp by viewModel.formMobileOtp.collectAsStateWithLifecycle()
    val otpVerified by viewModel.formMobileVerified.collectAsStateWithLifecycle()
    val email by viewModel.formEmail.collectAsStateWithLifecycle()
    val state by viewModel.formState.collectAsStateWithLifecycle()
    val district by viewModel.formDistrict.collectAsStateWithLifecycle()
    val pincode by viewModel.formPincode.collectAsStateWithLifecycle()
    val category by viewModel.formCategory.collectAsStateWithLifecycle()
    val dob by viewModel.formDob.collectAsStateWithLifecycle()
    val gender by viewModel.formGender.collectAsStateWithLifecycle()
    val occupation by viewModel.formOccupation.collectAsStateWithLifecycle()

    val income by viewModel.formIncome.collectAsStateWithLifecycle()
    val familyDetails by viewModel.formFamilyDetails.collectAsStateWithLifecycle()
    val caste by viewModel.formCaste.collectAsStateWithLifecycle()
    val disability by viewModel.formDisability.collectAsStateWithLifecycle()
    val farmer by viewModel.formFarmer.collectAsStateWithLifecycle()
    val student by viewModel.formStudent.collectAsStateWithLifecycle()
    val businessOwner by viewModel.formBusinessOwner.collectAsStateWithLifecycle()
    val benefits by viewModel.formExistingBenefits.collectAsStateWithLifecycle()

    val uploadedDocs by viewModel.uploadedDocumentsMap.collectAsStateWithLifecycle()
    val confirmChecked by viewModel.isFormConfirmChecked.collectAsStateWithLifecycle()
    val payMethod by viewModel.selectedPaymentMethod.collectAsStateWithLifecycle()
    val orderId by viewModel.generatedOrderId.collectAsStateWithLifecycle()
    val appId by viewModel.generatedAppId.collectAsStateWithLifecycle()
    val paymentId by viewModel.generatedPaymentId.collectAsStateWithLifecycle()
    val subDate by viewModel.submissionDate.collectAsStateWithLifecycle()

    val fees by viewModel.guidanceFees.collectAsStateWithLifecycle()
    val guidanceFee = fees[finalSchemeId] ?: 149

    var sendOtpTriggered by remember { mutableStateOf(false) }
    var otpVerifyError by remember { mutableStateOf(false) }
    var payOtpCode by remember { mutableStateOf("") }
    var showPayOtpDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        // App bar
        TopAppBar(
            title = { Text(if (isHindi) "सहायता आवेदन फॉर्म" else "Assisted Application Form", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 16.sp) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateTo("apply_scheme") }) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextNavy)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        // Linear Stepper indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 1..6) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(if (step >= i) GreenPrimary else Color.LightGray),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(i.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = when (i) {
                            1 -> if (isHindi) "व्यक्तिगत" else "Personal"
                            2 -> if (isHindi) "पात्रता" else "Eligibility"
                            3 -> if (isHindi) "दस्तावेज़" else "Docs"
                            4 -> if (isHindi) "समीक्षा" else "Review"
                            5 -> if (isHindi) "भुगतान" else "Payment"
                            else -> if (isHindi) "पूर्ण" else "Done"
                        },
                        fontSize = 8.sp,
                        color = if (step >= i) GreenPrimary else Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (i < 6) {
                    Divider(modifier = Modifier.width(8.dp).height(1.dp), color = if (step > i) GreenPrimary else Color.LightGray)
                }
            }
        }

        // Stepper Form Contents container
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = when (step) {
                        1 -> if (isHindi) "चरण 1: व्यक्तिगत जानकारी" else "Step 1: Personal Details & Contact"
                        2 -> if (isHindi) "चरण 2: योजना विशिष्ट पात्रता" else "Step 2: Scheme Specific Details"
                        3 -> if (isHindi) "चरण 3: सुरक्षित दस्तावेज़ अपलोड (M3 File Upload)" else "Step 3: Document Uploads"
                        4 -> if (isHindi) "चरण 4: आवेदन समीक्षा और संपादन" else "Step 4: Review Your Details"
                        5 -> if (isHindi) "चरण 5: वरिष्ठ विशेषज्ञ सेवा शुल्क" else "Step 5: Document Guidance Fee"
                        else -> if (isHindi) "चरण 6: आवेदन सफलतापूर्वक प्राप्त हुआ" else "Step 6: Application Filed Successfully"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = TextNavy
                )
            }

            when (step) {
                1 -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { viewModel.formFullName.value = it },
                                    label = { Text("Full Name (as in Aadhaar)") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = email,
                                    onValueChange = { viewModel.formEmail.value = it },
                                    label = { Text("Email Address") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = dob,
                                        onValueChange = { viewModel.formDob.value = it },
                                        label = { Text("Date of Birth (DD/MM/YYYY)") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = gender,
                                        onValueChange = { viewModel.formGender.value = it },
                                        label = { Text("Gender") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = state,
                                        onValueChange = { viewModel.formState.value = it },
                                        label = { Text("State") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = district,
                                        onValueChange = { viewModel.formDistrict.value = it },
                                        label = { Text("District") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                OutlinedTextField(
                                    value = pincode,
                                    onValueChange = { viewModel.formPincode.value = it },
                                    label = { Text("Pincode") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = category,
                                        onValueChange = { viewModel.formCategory.value = it },
                                        label = { Text("Social Category (Gen/OBC/SC/ST)") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = occupation,
                                        onValueChange = { viewModel.formOccupation.value = it },
                                        label = { Text("Occupation") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, if (otpVerified) GreenPrimary else OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Multi-Factor Phone Verification", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Aadhaar OTP linkage verification is required to verify identity.", fontSize = 11.sp, color = Color.Gray)
                                
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = mobile,
                                        onValueChange = { viewModel.formMobile.value = it },
                                        label = { Text("Aadhaar Linked Mobile") },
                                        modifier = Modifier.weight(1f),
                                        placeholder = { Text("9876543210") },
                                        enabled = !otpVerified
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = { sendOtpTriggered = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                        enabled = mobile.length == 10 && !otpVerified
                                    ) {
                                        Text("Send OTP", color = Color.White, fontSize = 11.sp)
                                    }
                                }

                                if (sendOtpTriggered && !otpVerified) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedTextField(
                                            value = otp,
                                            onValueChange = { viewModel.formMobileOtp.value = it },
                                            label = { Text("Enter 4-Digit OTP") },
                                            modifier = Modifier.weight(1f),
                                            placeholder = { Text("Type 1234") }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = {
                                                if (otp == "1234") {
                                                    viewModel.verifyFormOtp(mobile, otp)
                                                    otpVerifyError = false
                                                } else {
                                                    otpVerifyError = true
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer)
                                        ) {
                                            Text("Verify OTP", color = Color.White, fontSize = 11.sp)
                                        }
                                    }
                                    if (otpVerifyError) {
                                        Text("Invalid OTP code. Type 1234 for testing.", color = Color.Red, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                                    }
                                }

                                if (otpVerified) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Mobile verified securely via UIDAI.", color = GreenPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = { viewModel.setApplyFlowStep(2) },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier.fillMaxWidth(),
                            enabled = name.isNotEmpty() && otpVerified
                        ) {
                            Text("Next: Eligibility & Income", color = Color.White)
                        }
                    }
                }

                2 -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Scheme Specific Attributes", fontWeight = FontWeight.Bold, color = TextNavy)

                                OutlinedTextField(
                                    value = income,
                                    onValueChange = { viewModel.formIncome.value = it },
                                    label = { Text("Annual Family Income (Verified)") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = caste,
                                    onValueChange = { viewModel.formCaste.value = it },
                                    label = { Text("Sub-Caste Details (Required for Category benefits)") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = familyDetails,
                                    onValueChange = { viewModel.formFamilyDetails.value = it },
                                    label = { Text("Family Member Demographics") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Divider()

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Are you a registered Farmer?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = farmer, onCheckedChange = { viewModel.formFarmer.value = it })
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Are you a registered Student?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = student, onCheckedChange = { viewModel.formStudent.value = it })
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Are you physically disabled?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = disability, onCheckedChange = { viewModel.formDisability.value = it })
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Do you own a business enterprise?", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = businessOwner, onCheckedChange = { viewModel.formBusinessOwner.value = it })
                                }

                                OutlinedTextField(
                                    value = benefits,
                                    onValueChange = { viewModel.formExistingBenefits.value = it },
                                    label = { Text("List of current Government Scheme benefits received") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.setApplyFlowStep(1) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Back", color = TextNavy)
                            }
                            Button(
                                onClick = { viewModel.setApplyFlowStep(3) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Next: Upload Docs", color = Color.White)
                            }
                        }
                    }
                }

                3 -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Assisted Document Room", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 15.sp)
                                Text("Our expert team checks each document for clarity, spelling, and mismatch errors prior to submission. Safe & encrypted.", fontSize = 11.sp, color = Color.Gray)
                                
                                Spacer(modifier = Modifier.height(12.dp))

                                scheme.requiredDocuments.forEach { docType ->
                                    val upState = uploadedDocs[docType]
                                    val isUploaded = upState?.second ?: false
                                    val progress = upState?.first ?: 0
                                    val sizeStr = upState?.third ?: "0 KB"

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    imageVector = if (isUploaded) Icons.Default.CheckCircle else Icons.Default.Description,
                                                    contentDescription = null,
                                                    tint = if (isUploaded) GreenPrimary else Color.Gray,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(docType, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextNavy)
                                            }

                                            if (!isUploaded && progress == 0) {
                                                Button(
                                                    onClick = { viewModel.simulateDocumentUpload(docType) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceBg),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(12.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Upload", color = GreenPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Text(
                                                    text = if (isUploaded) "Uploaded • $sizeStr" else "Uploading $progress%",
                                                    fontSize = 11.sp,
                                                    color = if (isUploaded) GreenPrimary else SaffronSecondary,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        if (progress in 1..99) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            LinearProgressIndicator(
                                                progress = progress / 100f,
                                                color = SaffronContainer,
                                                modifier = Modifier.fillMaxWidth().height(4.dp)
                                            )
                                        }

                                        Divider(color = OutlineColor.copy(alpha = 0.2f), modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.setApplyFlowStep(2) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Back", color = TextNavy)
                            }
                            Button(
                                onClick = { viewModel.setApplyFlowStep(4) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.weight(1f),
                                enabled = scheme.requiredDocuments.all { uploadedDocs[it]?.second == true }
                            ) {
                                Text("Next: Review Form", color = Color.White)
                            }
                        }
                    }
                }

                4 -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Personal Details Summary", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 14.sp)
                                    TextButton(onClick = { viewModel.setApplyFlowStep(1) }) {
                                        Text("Edit Step 1", fontSize = 11.sp, color = GreenPrimary)
                                    }
                                }
                                Text("• Full Name: $name", fontSize = 13.sp)
                                Text("• Mobile: $mobile", fontSize = 13.sp)
                                Text("• Email: $email", fontSize = 13.sp)
                                Text("• DOB / Gender: $dob • $gender", fontSize = 13.sp)
                                Text("• Address: $district, $state - $pincode", fontSize = 13.sp)
                                Text("• Social Class: $category", fontSize = 13.sp)

                                Divider()

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Eligibility & Demographics Summary", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 14.sp)
                                    TextButton(onClick = { viewModel.setApplyFlowStep(2) }) {
                                        Text("Edit Step 2", fontSize = 11.sp, color = GreenPrimary)
                                    }
                                }
                                Text("• Verified Income: $income", fontSize = 13.sp)
                                Text("• Caste / Lineage: $caste", fontSize = 13.sp)
                                Text("• Occupation: $occupation", fontSize = 13.sp)
                                Text("• Farmer / Student: $farmer / $student", fontSize = 13.sp)
                                Text("• Physical Disability: $disability", fontSize = 13.sp)

                                Divider()

                                Text("Uploaded Documents Room (${uploadedDocs.size} files)", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 14.sp)
                                uploadedDocs.forEach { (docType, docData) ->
                                    Text("✓ $docType (${docData.third})", fontSize = 12.sp, color = GreenPrimary)
                                }
                            }
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = confirmChecked, onCheckedChange = { viewModel.isFormConfirmChecked.value = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("I confirm that all entered details match my original government identity cards.", fontSize = 11.sp, color = TextNavy)
                        }
                    }

                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.setApplyFlowStep(3) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Back", color = TextNavy)
                            }
                            Button(
                                onClick = { viewModel.setApplyFlowStep(5) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.weight(1f),
                                enabled = confirmChecked
                            ) {
                                Text("Next: Secure Payment", color = Color.White)
                            }
                        }
                    }
                }

                5 -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Payment Summary - Senior Guidance Service", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 15.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("This fee is strictly for application guidance, checklist verification, and direct digital filing assistance.", fontSize = 11.sp, color = Color.Gray)
                                
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Application Guidance Fee", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                    Text("₹$guidanceFee", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Platform Charges & GST", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = Color.Gray)
                                    Text("₹0 (Free Promo)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = GreenPrimary)
                                }

                                Divider(modifier = Modifier.padding(vertical = 10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Total Net Fee Payable", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = TextNavy)
                                    Text("₹$guidanceFee", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = GreenPrimary)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Select Secure Payment Method", fontWeight = FontWeight.Bold, color = TextNavy)

                                listOf("UPI (PhonePe, GPay)", "Credit/Debit Card", "Net Banking", "Secure Wallet").forEach { method ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.selectedPaymentMethod.value = method }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = payMethod == method,
                                            onClick = { viewModel.selectedPaymentMethod.value = method },
                                            colors = RadioButtonDefaults.colors(selectedColor = GreenPrimary)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(method, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = { showPayOtpDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Proceed to Secure Payment (₹$guidanceFee)", color = Color.White)
                        }
                    }
                }

                6 -> {
                    // Application Submitted Success Screen!
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, GreenPrimary.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Success", tint = GreenPrimary, modifier = Modifier.size(56.dp))
                                
                                Text(
                                    text = if (isHindi) "आवेदन सफलतापूर्वक जमा हुआ!" else "Application Received Successfully!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = GreenPrimary,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )

                                Text(
                                    text = if (isHindi) 
                                        "हमारे वरिष्ठ योजनमित्र अधिकारी को आपका फॉर्म आवंटित कर दिया गया है। वे 24 घंटों के भीतर समीक्षा करेंगे।" 
                                        else "Your document file has been securely delivered to our senior YojanaMitra desk officer. They will verify spelling, details, and lodge with SDM portal within 24 hours.",
                                    fontSize = 12.sp,
                                    color = TextGray,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    lineHeight = 18.sp
                                )

                                Divider(color = OutlineColor.copy(alpha = 0.2f))

                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Application ID:", fontSize = 12.sp, color = Color.Gray)
                                        Text(appId, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextNavy)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Payment Transaction ID:", fontSize = 12.sp, color = Color.Gray)
                                        Text(paymentId, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextNavy)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Guidance Fee Invoice:", fontSize = 12.sp, color = Color.Gray)
                                        Text(orderId, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextNavy)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Filing Date:", fontSize = 12.sp, color = Color.Gray)
                                        Text(subDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = TextNavy)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Filing Status:", fontSize = 12.sp, color = Color.Gray)
                                        Text("Documents Received (Expert Assigned)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SaffronSecondary)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = GreenPrimary.copy(alpha = 0.05f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("📅 Estimated Resolution Timeline", fontWeight = FontWeight.Bold, color = GreenPrimary, fontSize = 13.sp)
                                Text("• Stage 1 (Expert Review): Completes in 4 Hours", fontSize = 12.sp, color = TextNavy)
                                Text("• Stage 2 (Draft Verification): Completes in 12 Hours", fontSize = 12.sp, color = TextNavy)
                                Text("• Stage 3 (Direct SDM Filing): Completes in 24 Hours", fontSize = 12.sp, color = TextNavy)
                            }
                        }
                    }

                    item {
                        val ctx = androidx.compose.ui.platform.LocalContext.current
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    android.widget.Toast.makeText(ctx, "Receipt downloaded as PDF successfully!", android.widget.Toast.LENGTH_LONG).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, GreenPrimary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Receipt, contentDescription = null, tint = GreenPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Download Official Tax Receipt", color = GreenPrimary)
                            }

                            Button(
                                onClick = {
                                    viewModel.trackMobile.value = mobile
                                    viewModel.trackAppId.value = appId
                                    viewModel.trackOtp.value = "1234"
                                    viewModel.trackOtpSent.value = true
                                    viewModel.trackOtpVerified.value = true
                                    // Search tracking application
                                    viewModel.verifyTrackingOtpAndSearch(mobile, appId, "1234")
                                    viewModel.navigateTo("track_application")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Track Live Status (MFA)", color = Color.White)
                            }

                            Button(
                                onClick = {
                                    viewModel.navigateTo("dashboard")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Go to My Applications", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPayOtpDialog) {
        AlertDialog(
            onDismissRequest = { showPayOtpDialog = false },
            title = { Text("Secure payment 3D-OTP authentication") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("A 3D-Secure secure passcode has been dispatched to your Aadhaar linked mobile. Enter below to authenticate.")
                    OutlinedTextField(
                        value = payOtpCode,
                        onValueChange = { payOtpCode = it },
                        label = { Text("Enter OTP Code (type 1234)") },
                        placeholder = { Text("1234") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (payOtpCode == "1234") {
                            showPayOtpDialog = false
                            viewModel.submitAssistedApplication()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                    enabled = payOtpCode.length == 4
                ) {
                    Text("Pay Safely", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPayOtpDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}

// ==========================================
// NEW SCREEN: TRACK APPLICATION (MFA INTEGRITY SEARCH)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackApplicationScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val trackMobile by viewModel.trackMobile.collectAsStateWithLifecycle()
    val trackAppId by viewModel.trackAppId.collectAsStateWithLifecycle()
    val trackOtp by viewModel.trackOtp.collectAsStateWithLifecycle()
    val otpSent by viewModel.trackOtpSent.collectAsStateWithLifecycle()
    val otpVerified by viewModel.trackOtpVerified.collectAsStateWithLifecycle()
    val matchApp by viewModel.trackedApplication.collectAsStateWithLifecycle()

    var showTimelineInfo by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        TopAppBar(
            title = { Text(if (isHindi) "आवेदन स्थिति खोजें" else "MFA Application Tracker", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 16.sp) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateTo("dashboard") }) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextNavy)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Search & Verify Application Identity", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextNavy)
                        Text("To protect user identity, you must verify Aadhaar-OTP before status access.", fontSize = 11.sp, color = Color.Gray)

                        OutlinedTextField(
                            value = trackMobile,
                            onValueChange = { viewModel.trackMobile.value = it },
                            label = { Text("Aadhaar Registered Phone") },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !otpVerified
                        )

                        OutlinedTextField(
                            value = trackAppId,
                            onValueChange = { viewModel.trackAppId.value = it },
                            label = { Text("Application ID / Scheme Name") },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("e.g. pm_kisan or APP-12849") },
                            enabled = !otpVerified
                        )

                        if (!otpSent) {
                            Button(
                                onClick = { viewModel.sendTrackingOtp(trackMobile, trackAppId) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.fillMaxWidth(),
                                enabled = trackMobile.length == 10 && trackAppId.isNotEmpty()
                            ) {
                                Text("Send Verification OTP", color = Color.White)
                            }
                        } else if (!otpVerified) {
                            Divider()
                            Text("Passcode Dispatched!", fontWeight = FontWeight.Bold, color = SaffronSecondary, fontSize = 12.sp)
                            
                            OutlinedTextField(
                                value = trackOtp,
                                onValueChange = { viewModel.trackOtp.value = it },
                                label = { Text("Enter 4-Digit OTP") },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Type 1234") }
                            )

                            Button(
                                onClick = { viewModel.verifyTrackingOtpAndSearch(trackMobile, trackAppId, trackOtp) },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                modifier = Modifier.fillMaxWidth(),
                                enabled = trackOtp.length == 4
                            ) {
                                Text("Verify & Track Application", color = Color.White)
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = GreenPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Aadhaar Multi-Factor Verified Successfully!", color = GreenPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            
                            Button(
                                onClick = {
                                    viewModel.trackOtpSent.value = false
                                    viewModel.trackOtpVerified.value = false
                                    viewModel.trackOtp.value = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Track Another Application", color = TextNavy)
                            }
                        }
                    }
                }
            }

            if (otpVerified && matchApp != null) {
                val app = matchApp!!
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, GreenPrimary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(app.schemeCategory.uppercase(), color = GreenPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                Text("Filing Date: ${app.appliedDate}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(app.schemeTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = TextNavy)
                            
                            Spacer(modifier = Modifier.height(10.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SurfaceBg, shape = RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text("Status: ${app.status}", fontWeight = FontWeight.Bold, color = SaffronSecondary, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(app.statusDetails, fontSize = 12.sp, color = TextNavy, lineHeight = 16.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Interactive Stepper Timeline
                            Text("Application Progress Steps", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(10.dp))

                            val stepsList = listOf(
                                "Documents Received" to "Expert verified your structural files and cleared spelling mismatches.",
                                "Under Review" to "Our filing officer drafted the digital scheme layout with block entries.",
                                "Expert Assigned" to "Senior liaison officer verified your draft ledger entries.",
                                "Submitted Successfully" to "Filing receipt fetched from direct government SDM department portal.",
                                "Completed" to "Yojana benefits unlocked successfully. Check DBT bank records."
                            )

                            stepsList.forEachIndexed { idx, (title, desc) ->
                                val active = app.status == title || (idx == 0 && app.status == "Documents Pending")
                                val done = when (app.status) {
                                    "Completed" -> true
                                    "Submitted Successfully" -> idx < 4
                                    "Expert Assigned" -> idx < 3
                                    "Under Review" -> idx < 2
                                    "Documents Received" -> idx < 1
                                    else -> false
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(CircleShape)
                                                .background(if (done) GreenPrimary else if (active) SaffronContainer else Color.LightGray)
                                        )
                                        if (idx < 4) {
                                            Divider(modifier = Modifier.width(2.dp).height(24.dp).background(if (done) GreenPrimary else Color.LightGray))
                                        }
                                    }
                                    Column {
                                        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (active) SaffronSecondary else if (done) GreenPrimary else Color.Gray)
                                        Text(desc, fontSize = 11.sp, color = Color.Gray, lineHeight = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// NEW SCREEN: ADMIN PORTAL (CONFIGURATOR & STATUS UPDATER)
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(viewModel: YojanaViewModel, isHindi: Boolean) {
    val applications by viewModel.allApplications.collectAsStateWithLifecycle()
    val fees by viewModel.guidanceFees.collectAsStateWithLifecycle()

    var activeAdminTab by remember { mutableStateOf("apps") } // apps, pricing, reporting
    var selectedAppToEdit by remember { mutableStateOf<ApplicationEntity?>(null) }
    
    // Status update variables
    var statusSelection by remember { mutableStateOf("Under Review") }
    var detailsInput by remember { mutableStateOf("") }
    var expertInput by remember { mutableStateOf("") }
    var adminNotes by remember { mutableStateOf("") }

    // Pricing edit variables
    var selectedSchemePriceKey by remember { mutableStateOf("pm_kisan") }
    var schemePriceInput by remember { mutableStateOf("149") }

    // Simulated Exporting progress
    val coroutineScope = rememberCoroutineScope()
    var exportProgress by remember { mutableStateOf(0f) }
    var isExporting by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBg)
    ) {
        // App Bar
        TopAppBar(
            title = { Text("YojanaMitra Admin Portal", fontWeight = FontWeight.Bold, color = TextNavy, fontSize = 16.sp) },
            navigationIcon = {
                IconButton(onClick = { viewModel.navigateTo("profile") }) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextNavy)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
        )

        // Tab selection
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(vertical = 8.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val adminTabs = listOf(
                "apps" to "Applications Review",
                "pricing" to "Configure Pricing",
                "reporting" to "Export Reports"
            )
            adminTabs.forEach { (key, label) ->
                val selected = activeAdminTab == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) SaffronContainer else SurfaceBg)
                        .clickable { activeAdminTab = key }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else TextNavy)
                }
            }
        }

        Divider()

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeAdminTab) {
                "apps" -> {
                    item {
                        Text("Active Applications In System (${applications.size} Found)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    items(applications) { app ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedAppToEdit = app
                                    statusSelection = app.status
                                    detailsInput = app.statusDetails
                                },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("APP ID: #${app.id}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GreenPrimary)
                                    Box(
                                        modifier = Modifier
                                            .background(SaffronContainer.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(app.status.uppercase(), color = SaffronSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(app.schemeTitle, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextNavy)
                                Text("Applied on: ${app.appliedDate} • Mode: ${if (app.isPaidAssistance) "Assisted (₹${app.paidAmount})" else "Free Self"}", fontSize = 11.sp, color = Color.Gray)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Details: ${app.statusDetails}", fontSize = 11.sp, color = TextGray, maxLines = 1)
                                
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Click to edit / update status", fontSize = 11.sp, color = GreenPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                "pricing" -> {
                    item {
                        Text("Configure Assisted Guidance Fees", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Dynamic Fee Real-time Editor", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                                fees.keys.forEach { schemeId ->
                                    val fee = fees[schemeId] ?: 0
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedSchemePriceKey = schemeId
                                                schemePriceInput = fee.toString()
                                            }
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(
                                                selected = selectedSchemePriceKey == schemeId,
                                                onClick = {
                                                    selectedSchemePriceKey = schemeId
                                                    schemePriceInput = fee.toString()
                                                },
                                                colors = RadioButtonDefaults.colors(selectedColor = GreenPrimary)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(schemeId.uppercase().replace("_", " "), fontSize = 13.sp)
                                        }
                                        Text("₹$fee", fontWeight = FontWeight.Bold, color = GreenPrimary, fontSize = 13.sp)
                                    }
                                }

                                Divider()

                                OutlinedTextField(
                                    value = schemePriceInput,
                                    onValueChange = { schemePriceInput = it },
                                    label = { Text("Guidance Fee for ${selectedSchemePriceKey.uppercase()}") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = {
                                        val price = schemePriceInput.toIntOrNull() ?: 149
                                        viewModel.adminConfigureFee(selectedSchemePriceKey, price)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Apply Pricing Change", color = Color.White)
                                }
                            }
                        }
                    }
                }

                "reporting" -> {
                    item {
                        Text("Business Intelligence & Financial Reports", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, OutlineColor.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Simulate Financial Exports", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Generate encrypted compliance reports containing scheme volumes, fees, and audit trails.", fontSize = 11.sp, color = Color.Gray)

                                if (isExporting) {
                                    LinearProgressIndicator(
                                        progress = exportProgress,
                                        modifier = Modifier.fillMaxWidth(),
                                        color = SaffronContainer
                                    )
                                    Text("Progress: ${(exportProgress * 100).toInt()}% • $exportMessage", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SaffronSecondary)
                                }

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            isExporting = true
                                            exportProgress = 0f
                                            coroutineScope.launch {
                                                exportMessage = "Drafting SQL ledger entries..."
                                                for (i in 1..10) {
                                                    kotlinx.coroutines.delay(200)
                                                    exportProgress = i / 10f
                                                    if (i == 4) exportMessage = "Formulating PDF visual template..."
                                                    if (i == 8) exportMessage = "Compressing files & signing MD5 hash..."
                                                }
                                                exportMessage = "Report downloaded successfully to Device Downloads!"
                                                isExporting = false
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Export PDF", color = Color.White, fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            isExporting = true
                                            exportProgress = 0f
                                            coroutineScope.launch {
                                                exportMessage = "Formatting Excel grid sheets..."
                                                for (i in 1..10) {
                                                    kotlinx.coroutines.delay(200)
                                                    exportProgress = i / 10f
                                                    if (i == 5) exportMessage = "Aggregating guidance fees margins..."
                                                }
                                                exportMessage = "Spreadsheet generated successfully!"
                                                isExporting = false
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SaffronContainer),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Export Excel", color = Color.White, fontSize = 11.sp)
                                    }
                                }

                                if (exportMessage.isNotEmpty() && !isExporting) {
                                    Text("✓ $exportMessage", color = GreenPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Selected Application Action Drawer
    selectedAppToEdit?.let { app ->
        AlertDialog(
            onDismissRequest = { selectedAppToEdit = null },
            title = { Text("Edit Application ID #${app.id}", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Scheme: ${app.schemeTitle}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Applicant Name: Rajesh Kumar", fontSize = 12.sp)

                    Divider()

                    Text("Update Flow Status", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    listOf("Documents Received", "Under Review", "Expert Assigned", "Submitted Successfully", "Completed").forEach { status ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { statusSelection = status }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = statusSelection == status,
                                onClick = { statusSelection = status },
                                colors = RadioButtonDefaults.colors(selectedColor = GreenPrimary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(status, fontSize = 12.sp)
                        }
                    }

                    OutlinedTextField(
                        value = detailsInput,
                        onValueChange = { detailsInput = it },
                        label = { Text("Status description update") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = expertInput,
                        onValueChange = { expertInput = it },
                        label = { Text("Assign Executive Expert") },
                        placeholder = { Text("e.g. Vikram Singh") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = adminNotes,
                        onValueChange = { adminNotes = it },
                        label = { Text("Internal Admin Notes (Private)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminUpdateStatus(app.id, statusSelection, detailsInput)
                        if (expertInput.isNotEmpty()) {
                            viewModel.adminAssignExpert(app.id, expertInput)
                        }
                        selectedAppToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary)
                ) {
                    Text("Save Status Changes", color = Color.White)
                }
            },
            dismissButton = {
                Row {
                    if (app.isPaidAssistance && app.paidAmount > 0) {
                        Button(
                            onClick = {
                                viewModel.adminRefundPayment(app.id)
                                selectedAppToEdit = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f))
                        ) {
                            Text("Refund ₹${app.paidAmount}", color = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    TextButton(onClick = { selectedAppToEdit = null }) {
                        Text("Cancel", color = Color.Gray)
                    }
                }
            }
        )
    }
}
